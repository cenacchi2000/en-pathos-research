# En-Pathos

[Project website](docs/index.html) · [Study code](code/live) · [Temporal diagnostic](code/temporal) · [Reply adapter](code/en-pathos-listener)

The project evaluates three outcomes. An edited-footage task measures order and span prediction. A separate SmolLM2 study measures likelihood of recorded replies. The live recipient study evaluates Gemma with pacing and self-confirmed preference cards.

## Reproduce the components

- For the temporal diagnostic, run `python code/temporal/temporal.py --help`. Supply source videos and MELD annotations obtained under the original data terms. For an exact split, pass the archived source-group manifest.
- For the reply adapter, run `python code/en-pathos-listener/train.py --help`. Supply the base SmolLM2-135M-Instruct identifier, prepared JSONL turns and a fresh output directory. To mirror the mixed run pass `--train-examples 18366 --eval-examples 5154 --epochs 1 --retain-training-video`. The corpus assembly scripts are under `code/data`; these are research scripts and expect the corpus-specific directory layout and local access described in the supplement.
- For the study, install `code/live/requirements.txt`, run the configured local language-model server and supply a trained adapter directory. Run `python code/live/server.py --help` for ports, origins and checkpoint arguments. Use a fresh ratings database. Access over localhost or HTTPS for microphone and camera permissions.
- The checked-in screenshots show the game and a redacted conversation view. GitHub Pages serves the project description. The interactive study needs the Python backend.

Repository contents exclude participant records, recordings, raw corpus media and credentials. Exact numerical reproduction also requires the original dataset subsets, manifests and checkpoints.
