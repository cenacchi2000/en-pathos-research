"""Grouped probe of semantic direction labels on released real footage."""
import argparse
import hashlib
import json
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import av
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from temporal import SIZE, STEPS, TemporalEncoder, read_clip


def load(path, metadata):
    files = {p.name: p for p in path.rglob("*.mp4")}
    pairs = defaultdict(dict)
    for row in json.loads(metadata.read_text()):
        name = Path(row["video"]).name
        if name in files:
            reversed_clip = name.endswith("_reversed.mp4")
            stem = name.removesuffix("_reversed.mp4") if reversed_clip else Path(name).stem
            pairs[stem][int(reversed_clip)] = (files[name], row)
    def decode(record):
        stem, pair = record
        if len(pair) != 2:
            return None
        try:
            a, b = pair[0][1], pair[1][1]
            if a["question"] != b["question"] or a["answer"] == b["answer"]:
                return None
            frames = read_clip(pair[0][0])
            # Reverse the exact sampled frames to prevent codec artefact shortcuts.
            return stem, a["source_subcategory"], a["question"], a["answer"], b["answer"], frames
        except (av.FFmpegError, ValueError, OSError):
            return None
    with ThreadPoolExecutor(max_workers=6) as pool:
        return [r for r in pool.map(decode, sorted(pairs.items())) if r is not None]


def grouping(record):
    stem, source, *_ = record
    # The eight-digit synthetic naming scheme shares a four-digit family prefix.
    return f"{source}/{stem[:4]}" if stem.isdecimal() and len(stem) == 8 else f"{source}/{stem}"


class Classifier(nn.Module):
    def __init__(self, mode, n):
        super().__init__()
        self.mode = mode
        self.model = TemporalEncoder(n) if mode == "temporal" else nn.Sequential(
            nn.Flatten(), nn.Linear(SIZE * SIZE, 64), nn.GELU(), nn.Linear(64, n))

    def forward(self, frames):
        return self.model(frames)[2] if self.mode == "temporal" else self.model(frames[:, STEPS // 2])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("videos", type=Path)
    parser.add_argument("metadata", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(4)
    records = load(args.videos, args.metadata)
    by_question = defaultdict(set)
    for r in records:
        by_question[r[2]].add(grouping(r))
    train, test = [], []
    for question, groups in by_question.items():
        if len(groups) < 4:
            continue
        groups = sorted(groups, key=lambda x: hashlib.sha256(f"42/{x}".encode()).hexdigest())
        held = set(groups[:max(1, len(groups) // 4)])
        for r in records:
            if r[2] == question:
                (test if grouping(r) in held else train).append(r)
    # Keep every source group on one side even when it appears under different questions.
    held = {grouping(r) for r in test}
    train = [r for r in train if grouping(r) not in held]
    keys = sorted({(r[2], answer) for r in train for answer in r[3:5]})
    indices = {k: i for i, k in enumerate(keys)}
    test = [r for r in test if all((r[2], a) in indices for a in r[3:5])]
    if not train or not test:
        raise SystemExit("No question families with sufficient grouped coverage.")
    def batch(rows, mode):
        clips = []
        for r in rows:
            f = r[5]
            if mode == "shuffled":
                f = f[np.random.default_rng(42).permutation(STEPS)]
                clips.extend((f, f))
            else:
                clips.extend((f, f[::-1]))
        x = torch.tensor(np.stack(clips)).float().div(255)
        y = torch.tensor([indices[r[2], a] for r in rows for a in r[3:5]])
        valid = torch.tensor([[q == r[2] for q, _ in keys] for r in rows]).repeat_interleave(2, 0)
        return x, y, valid
    report = {"available_pairs": len(records), "train_pairs": len(train), "test_pairs": len(test),
              "test_questions": dict(Counter(r[2] for r in test)), "results": {},
              "train_ids": [r[0] for r in train], "test_ids": [r[0] for r in test]}
    for mode in ("text", "frame", "shuffled", "temporal"):
        torch.manual_seed(42)
        x, y, mask = batch(train, mode)
        t, gold, valid = batch(test, mode)
        if mode == "text":
            pred = valid.to(torch.int64).argmax(1)
        else:
            net = Classifier("temporal" if mode == "shuffled" else mode, len(keys))
            optim = torch.optim.AdamW(net.parameters(), lr=.001)
            for _ in range(12):
                for ids in torch.randperm(len(x)).split(64):
                    output = net(x[ids]).masked_fill(~mask[ids], -1e5)
                    loss = F.cross_entropy(output, y[ids])
                    optim.zero_grad()
                    loss.backward()
                    optim.step()
            net.eval()
            with torch.no_grad():
                pred = net(t).masked_fill(~valid, -1e5).argmax(1)
        right = pred.eq(gold)
        report["results"][mode] = {"accuracy": right.float().mean().item(),
                                   "pair_accuracy": right.view(-1, 2).all(1).float().mean().item()}
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print({k: v for k, v in report.items() if not k.endswith("ids")}, flush=True)


if __name__ == "__main__":
    main()
