"""Temporal evidence selection on counterfactual sequences built from real clips."""
import argparse
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import av
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from PIL import Image

STEPS = 12
SIZE = 24
TEXT = "Did you catch what happened just then?"
SOURCES = ("MELD", "HMDB51")


def read_clip(path):
    with av.open(str(path)) as stream:
        frames = [frame.to_ndarray(format="rgb24") for frame in stream.decode(video=0)]
    if len(frames) < STEPS:
        raise ValueError("Too few decoded frames")
    indices = np.linspace(0, len(frames) - 1, STEPS).round().astype(int)
    return np.stack([np.asarray(Image.fromarray(frames[i]).convert("L").resize((SIZE, SIZE),
                       Image.Resampling.BILINEAR)) for i in indices])


def load_sources(root, annotations, cache, limit, wanted=None):
    def meld_records():
        with annotations.open(encoding="utf-8-sig", errors="replace", newline="") as handle:
            rows = {f'dia{r["Dialogue_ID"]}_utt{r["Utterance_ID"]}': r for r in csv.DictReader(handle)}
        for path in sorted((root / "media").rglob("*.mp4")):
            if path.stem in rows:
                row = rows[path.stem]
                yield path, "MELD", f'{row["Season"]}/{row["Episode"]}', row["Emotion"]

    def hmdb_records():
        for path in sorted((root / "hmdb").glob("*.avi")):
            try:
                record = json.loads(path.with_suffix(".json").read_text())
            except (OSError, ValueError):
                continue
            filename = record["filename"]
            group = re.split(r'_(?:' + re.escape(record["label"]) + r')_[hmu]_', filename)[0]
            yield path, "HMDB51", group, record["label"]

    cache.mkdir(parents=True, exist_ok=True)
    candidates = list(meld_records()) + list(hmdb_records())
    if wanted is not None:
        candidates = [r for r in candidates if (r[1], r[0].stem) in wanted]
    candidates.sort(key=lambda r: hashlib.sha256(str(r[0].name).encode()).hexdigest())
    chosen, counts = [], Counter()
    for record in candidates:
        if counts[record[1]] < limit:
            chosen.append(record)
            counts[record[1]] += 1

    def decode(record):
        path, source, group, label = record
        key = hashlib.sha256(f"{source}/{path.name}/{path.stat().st_size}".encode()).hexdigest()
        cached = cache / (key + ".npy")
        try:
            if cached.exists():
                frames = np.load(cached, allow_pickle=False)
            else:
                frames = read_clip(path)
                np.save(cached, frames)
            return source, group, label, path.stem, frames
        except (av.FFmpegError, ValueError, OSError):
            return None

    with ThreadPoolExecutor(max_workers=6) as pool:
        return [result for result in pool.map(decode, chosen) if result is not None], counts


def split_records(records):
    groups = defaultdict(set)
    for source, group, _, _, _ in records:
        groups[source].add(group)
    assignments = {}
    for source, values in groups.items():
        ordered = sorted(values, key=lambda x: hashlib.sha256(f"42/{source}/{x}".encode()).hexdigest())
        held = max(1, len(ordered) // 5)
        for i, group in enumerate(ordered):
            assignments[source, group] = "test" if i < held else "val" if i < 2 * held else "train"
    return assignments


def arrays(records, seed):
    """Embed a 5-frame ordered excerpt inside identical frozen context frames.

    Swap by reversing only the excerpt. Positive and negative have the same
    multiset, duration, fixed outer frames, dialogue and background.
    """
    rng = np.random.default_rng(seed)
    videos, locations = [], []
    for _, _, _, _, frames in records:
        start = int(rng.integers(1, STEPS - 5))
        take = frames[2:7]
        background = np.repeat(frames[0:1], STEPS, axis=0)
        for cue in (take, take[::-1]):
            clip = background.copy()
            clip[start:start + 5] = cue
            videos.append(clip)
            locations.append(start)
    return np.stack(videos), np.asarray(locations)


class TemporalEncoder(nn.Module):
    """Learn frame and signed motion embeddings, then rank candidate intervals."""
    def __init__(self, categories):
        super().__init__()
        self.frame = nn.Sequential(nn.Linear(SIZE * SIZE, 64), nn.LayerNorm(64), nn.GELU())
        self.temporal = nn.Sequential(nn.Conv1d(128, 64, 3, padding=1), nn.GELU(),
                                      nn.Conv1d(64, 48, 3, padding=1), nn.GELU())
        self.span = nn.Linear(48, 1)
        self.order = nn.Sequential(nn.Linear(112, 32), nn.GELU(), nn.Linear(32, 2))
        self.aux = nn.Linear(48, categories)

    def forward(self, frames):
        x = self.frame(frames.flatten(2))
        diff = torch.diff(x, dim=1, prepend=x[:, :1])
        h = self.temporal(torch.cat((x, diff), dim=-1).transpose(1, 2)).transpose(1, 2)
        starts = h.unfold(1, 5, 1).mean(-1)
        spans = self.span(starts).squeeze(-1)
        embedding = (spans.softmax(-1).unsqueeze(-1) * starts).sum(1)
        drift = x[:, 1:] - x[:, :-1]
        windows = drift.unfold(1, 4, 1).sum(-1)
        direction = (spans.softmax(-1).unsqueeze(-1) * windows).sum(1)
        return self.order(torch.cat((embedding, direction), dim=-1)), spans, self.aux(embedding)


class FrameBaseline(nn.Module):
    def __init__(self):
        super().__init__()
        self.head = nn.Sequential(nn.Flatten(), nn.Linear(SIZE * SIZE, 64), nn.GELU(), nn.Linear(64, 2))

    def forward(self, x):
        return self.head(x[:, STEPS // 2])


def shuffled(video, seed):
    rng = np.random.default_rng(seed)
    # Identical permutations within each pair. An identical frame multiset
    # becomes identical input, so no order signal remains.
    result = video.clone()
    for i in range(0, len(video), 2):
        frames = video[i].numpy()
        canonical = sorted(range(STEPS), key=lambda j: frames[j].tobytes())
        permutation = rng.permutation(STEPS)
        shared = video[i, np.array(canonical)[permutation]]
        result[i:i + 2] = shared
    return result


def load_split(records, categories, seed):
    video, spans = arrays(records, seed)
    return (torch.from_numpy(video).float().div(255), torch.from_numpy(spans).long(),
            torch.arange(len(video)) % 2,
            torch.tensor([categories.get((r[0], r[2]), -100) for r in records]).repeat_interleave(2))


def fit(mode, train, validation, count, seed, epochs):
    torch.manual_seed(seed)
    net = FrameBaseline() if mode == "frame" else TemporalEncoder(count)
    optimizer = torch.optim.AdamW(net.parameters(), lr=.001, weight_decay=.01)
    train_x, spans, order, aux = train
    validation_x = validation[0]
    if mode == "shuffled":
        train_x = shuffled(train_x, 17)
        validation_x = shuffled(validation_x, 23)
    generator = torch.Generator().manual_seed(seed)
    best, history, state = -1, [], None
    for _ in range(epochs):
        net.train()
        for pairs in torch.randperm(len(order) // 2, generator=generator).split(32):
            indices = torch.stack((pairs * 2, pairs * 2 + 1), dim=1).flatten()
            x = train_x[indices]
            if mode == "frame":
                loss = F.cross_entropy(net(x), order[indices])
            else:
                pred, loc, tags = net(x)
                loss = F.cross_entropy(pred, order[indices])
                if mode == "temporal":
                    loss += F.cross_entropy(loc, spans[indices])
                    margins = (pred[:, 1] - pred[:, 0]).view(-1, 2)
                    loss += .4 * F.softplus(1 - margins[:, 1] + margins[:, 0]).mean()
                    loss += .3 * F.cross_entropy(tags, aux[indices])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        net.eval()
        with torch.no_grad():
            prediction = net(validation_x)
            logits = prediction if mode == "frame" else prediction[0]
            correct = logits.argmax(1).eq(validation[2])
            pair = correct.view(-1, 2).all(1).float().mean().item()
            acc = correct.float().mean().item()
        history.append({"accuracy": acc, "pair_accuracy": pair})
        score = pair + .01 * acc
        if score > best:
            best = score
            state = {name: value.detach().clone() for name, value in net.state_dict().items()}
    net.load_state_dict(state)
    return net, history


def score(mode, net, test, records):
    x, loc, labels, aux = test
    predicted_span = torch.full_like(loc, -1)
    predicted_aux = torch.full_like(aux, -1)
    if mode == "text":
        pred = torch.zeros_like(labels)
    elif mode == "frame":
        pred = net(x).argmax(-1)
    elif mode in ("motion", "center"):
        pred = torch.zeros_like(labels)
        if mode == "motion":
            movement = torch.diff(x, dim=1).abs().mean((-1, -2))
            predicted_span = movement.unfold(1, 4, 1).sum(-1).argmax(-1)
        else:
            predicted_span.fill_((STEPS - 5) // 2)
    else:
        logits, spans, tags = net(shuffled(x, 29) if mode == "shuffled" else x)
        pred = logits.argmax(-1)
        if mode == "temporal":
            predicted_span = spans.argmax(-1)
            predicted_aux = tags.argmax(-1)
    result = []
    for i, (source, group, label, clip, _) in enumerate(records):
        a, b = 2 * i, 2 * i + 2
        overlap = (5 - (loc[a:b] - predicted_span[a:b]).abs()).clamp(min=0)
        iou = overlap / (10 - overlap) if mode in ("temporal", "motion", "center") else None
        ok = pred[a:b].eq(labels[a:b])
        result.append(dict(source=source, group=group, clip=clip, source_label=label,
                           prediction=pred[a:b].tolist(), correct=ok.tolist(), span=int(loc[a]),
                           predicted_span=predicted_span[a:b].tolist(),
                           iou=iou.tolist() if iou is not None else None,
                           aux_correct=predicted_aux[a:b].eq(aux[a:b]).tolist()
                           if mode == "temporal" and aux[a] >= 0 else None))
    return result


def summarize(rows):
    return {
        "clips": len(rows),
        "accuracy": float(np.mean([r["correct"] for r in rows])),
        "pair_accuracy": float(np.mean([all(r["correct"]) for r in rows])),
        "grounded_pair_accuracy": float(np.mean([all(r["correct"]) and min(r["iou"]) >= .5 for r in rows]))
        if rows[0]["iou"] is not None else None,
        "mean_iou": float(np.mean([r["iou"] for r in rows])) if rows[0]["iou"] is not None else None,
        "aux_accuracy": float(np.mean([r["aux_correct"] for r in rows if r["aux_correct"] is not None]))
        if any(r["aux_correct"] is not None for r in rows) else None,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("media", type=Path)
    parser.add_argument("meld_annotations", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--limit", type=int, default=2500)
    parser.add_argument("--epochs", type=int, default=14)
    parser.add_argument("--manifest", type=Path, help="Restore the source membership and splits of a reported run.")
    args = parser.parse_args()
    torch.set_num_threads(4)
    args.out.mkdir(parents=True, exist_ok=True)
    frozen = json.loads(args.manifest.read_text()) if args.manifest else None
    wanted = {(r["source"], r["clip"]) for r in frozen} if frozen else None
    records, candidates = load_sources(args.media, args.meld_annotations, args.media / "cache", args.limit, wanted)
    if frozen:
        indexed = {(r[0], r[3]): r for r in records}
        missing = wanted - indexed.keys()
        if missing:
            raise SystemExit(f"{len(missing)} frozen source clips are missing or undecodable.")
        data = {split: [indexed[r["source"], r["clip"]] for r in frozen if r["split"] == split]
                for split in ("train", "val", "test")}
    else:
        assigned = split_records(records)
        data = {split: [r for r in records if assigned[r[:2]] == split] for split in ("train", "val", "test")}
    if any(not v for v in data.values()):
        raise SystemExit("Need nonempty group-disjoint train, validation and test partitions.")
    categories = {k: i for i, k in enumerate(sorted({(r[0], r[2]) for r in data["train"]}))}
    batches = {s: load_split(rs, categories, 42 + i) for i, (s, rs) in enumerate(data.items())}
    manifest = [{"source": r[0], "group": r[1], "label": r[2], "clip": r[3], "split": split}
                for split, rs in data.items() for r in rs]
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    report = {"candidates": dict(candidates), "split": {s: dict(Counter(r[0] for r in rs)) for s, rs in data.items()},
              "results": {}, "history": {}, "torch": torch.__version__, "epochs": args.epochs}
    print(report["split"], flush=True)
    for mode in ("text", "frame", "shuffled", "motion", "center", "temporal"):
        with torch.enable_grad():
            net, history = (None, []) if mode in ("text", "motion", "center") else fit(
                mode, batches["train"], batches["val"], len(categories), 42, args.epochs)
        with torch.no_grad():
            rows = score(mode, net, batches["test"], data["test"])
        report["results"][mode] = {"all": summarize(rows), **{
            source: summarize([r for r in rows if r["source"] == source])
            for source in sorted({r["source"] for r in rows})}}
        report["history"][mode] = history
        (args.out / f"{mode}-predictions.json").write_text(json.dumps(rows, indent=2) + "\n")
        (args.out / "metrics.json").write_text(json.dumps(report, indent=2) + "\n")
        if mode == "temporal":
            torch.save(net.state_dict(), args.out / "temporal.pt")
        print(mode, report["results"][mode], flush=True)


if __name__ == "__main__":
    main()
