"""Paired test-time interventions and cluster-bootstrap uncertainty."""
import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from temporal import TemporalEncoder, load_sources, load_split, score, summarize


def ci(rows, metric, seed=42):
    groups = defaultdict(list)
    for row in rows:
        groups[row["source"], row["group"]].append(metric(row))
    by_source = defaultdict(list)
    for (source, _), values in groups.items():
        by_source[source].append((sum(values), len(values)))
    rng = np.random.default_rng(seed)
    numerator, denominator = np.zeros(2000), np.zeros(2000)
    for values in by_source.values():
        cluster = np.asarray(values)
        draws = rng.integers(0, len(cluster), (2000, len(cluster)))
        sums = cluster[draws].sum(axis=1)
        numerator += sums[:, 0]
        denominator += sums[:, 1]
    return np.percentile(numerator / denominator, [2.5, 97.5]).tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("media", type=Path)
    parser.add_argument("annotations", type=Path)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(4)
    manifest = json.loads((args.results / "manifest.json").read_text())
    rows = [r for r in manifest if r["split"] == "test"]
    wanted = {(r["source"], r["clip"]) for r in rows}
    records, _ = load_sources(args.media, args.annotations, args.media / "cache", 100000, wanted)
    by_id = {(r[0], r[3]): r for r in records if (r[0], r[3]) in wanted}
    records = [by_id[r["source"], r["clip"]] for r in rows]
    categories = {k: i for i, k in enumerate(sorted({(r["source"], r["label"]) for r in manifest
                                                  if r["split"] == "train"}))}
    net = TemporalEncoder(len(categories))
    net.load_state_dict(torch.load(args.results / "temporal.pt", weights_only=True))
    net.eval()
    x, span, order, aux = load_split(records, categories, 44)
    relative = torch.arange(x.shape[1]).unsqueeze(0) - span.unsqueeze(1)
    evidence = ((relative >= 0) & (relative < 5)).unsqueeze(-1).unsqueeze(-1)
    for i in range(0, len(x), 2):
        left, left_counts = x[i].flatten(1).unique(dim=0, return_counts=True)
        right, right_counts = x[i + 1].flatten(1).unique(dim=0, return_counts=True)
        assert torch.equal(left, right) and torch.equal(left_counts, right_counts)
    missing = torch.where(evidence, x[:, :1], x)
    isolated = torch.where(evidence, x, torch.full_like(x, .5))
    report = {}
    with torch.no_grad():
        for name, inputs in {"original": x, "masked_cue": missing, "cue_only": isolated,
                             "brightness": (x * .75 + .18).clamp(0, 1)}.items():
            predictions = score("temporal", net, (inputs, span, order, aux), records)
            report[name] = summarize(predictions)
            report[name]["pair_ci95"] = ci(predictions, lambda r: all(r["correct"]))
            report[name]["iou_ci95"] = ci(predictions, lambda r: np.mean(r["iou"]))
    (args.results / "interventions.json").write_text(json.dumps(report, indent=2) + "\n")
    print(report)


if __name__ == "__main__":
    main()
