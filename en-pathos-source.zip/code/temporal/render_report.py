"""Render tables, figures, and the auditable 40-page supplement."""
import argparse
from collections import Counter
import json
from pathlib import Path
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).parent / "paper"
MODES = {"text": "Text", "frame": "Middle frame", "shuffled": "Shuffled", "motion": "Pixel motion",
         "center": "Center", "temporal": "Temporal"}
COLORS = ["#487490", "#278077", "#a86232"]


def pct(v):
    return "--" if v is None else f"{100*v:.1f}"


def table(caption, headings, rows, layout):
    return ("\\begin{table}[t]\\centering\\small\n\\caption{" + caption
            + "}\n\\begin{tabular}{" + layout + "}\\toprule\n" + " & ".join(headings)
            + r" \\ \midrule" + "\n" + "\n".join(" & ".join(map(str, row)) + r" \\" for row in rows)
            + "\n\\bottomrule\\end{tabular}\\end{table}\n")


def save(name):
    plt.savefig(ROOT / "fig" / (name + ".pdf"), bbox_inches="tight", pad_inches=.1)
    plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("results", type=Path)
    parser.add_argument("--dy", type=Path)
    args = parser.parse_args()
    metrics = json.loads((args.results / "metrics.json").read_text())
    interventions = json.loads((args.results / "interventions.json").read_text())
    manifest = json.loads((args.results / "manifest.json").read_text())
    p = json.loads((args.results / "temporal-predictions.json").read_text())
    dy = json.loads(args.dy.read_text()) if args.dy and args.dy.exists() else None
    modes = metrics["results"]
    n = len(manifest)
    test = len(p)
    nums = f"The completed run used {n:,} decoded source clips and evaluated {test:,} held-out pairs. Each source clip yields two edited versions."
    (ROOT / "numbers.tex").write_text(nums + "\n")
    fields = ["accuracy", "pair_accuracy", "grounded_pair_accuracy", "mean_iou"]
    tables = table("Number of source clips by partition.", ["Source", "Train", "Val.", "Test"],
                   [[s] + [metrics["split"][x].get(s, 0) for x in ("train","val","test")]
                    for s in ("MELD","HMDB51")], "lrrr")
    tables += table("Held-out results in percent. GPair requires both spans at IoU $\\geq 0.5$.",
                    ["Method","Acc.","Pair","GPair","IoU"],
                    [[MODES[k]]+[pct(v["all"][f]) for f in fields] for k,v in modes.items()], "lrrrr")
    tables += table("Ordered model by source, in percent.", ["Source","Pairs","Pair","GPair","IoU"],
                    [[s,v["clips"]] + [pct(v[f]) for f in fields[1:]]
                     for s,v in modes["temporal"].items() if s != "all"], "lrrrr")
    tables += table("Interventions on the same held-out pairs, in percent.",
                    ["Input","Pair","GPair","IoU"],
                    [[k.replace("_"," ").title()]+[pct(v[f]) for f in fields[1:]]
                     for k,v in interventions.items()], "lrrr")
    (ROOT / "tables.tex").write_text(tables)
    t=modes["temporal"]["all"]; base=modes["frame"]["all"]
    ci=interventions["original"]["pair_ci95"]
    summary = (f"The ordered model correctly classifies both variants in {pct(t['pair_accuracy'])}\\% of pairs, "
               f"with a source-cluster bootstrap interval of [{pct(ci[0])}, {pct(ci[1])}]\\%. "
               f"The middle-frame model reaches {pct(base['pair_accuracy'])}\\%. "
               f"The ordered model reaches {pct(t['grounded_pair_accuracy'])}\\% grounded pair accuracy. "
               f"Mean interval IoU is {pct(t['mean_iou'])}\\%, below the pixel-motion heuristic "
               f"at {pct(modes['motion']['all']['mean_iou'])}\\%. "
               "The localization baseline exposes the contribution of synthetic motion boundaries. "
               f"Auxiliary action or affect prediction accuracy is {pct(t['aux_accuracy'])}\\% over known labels. "
               f"The brightness edit changes pair accuracy to {pct(interventions['brightness']['pair_accuracy'])}\\%. "
               "Masking the entire inserted cue yields identical variants and zero strict pair accuracy. "
               "The cue-only condition replaces the original context with gray and also changes boundaries. "
               "Its score measures performance under this specific perturbation.")
    if dy:
        summary += ("\\paragraph{Semantic direction.} On a separately fitted grouped DyBench probe, "
                    f"we train on {dy['train_pairs']} pairs and evaluate on {dy['test_pairs']}. "
                    f"Temporal pair accuracy is {pct(dy['results']['temporal']['pair_accuracy'])}\\% "
                    f"and middle-frame pair accuracy is {pct(dy['results']['frame']['pair_accuracy'])}\\%. "
                    "The question restricts the candidate classes. This probe predicts observable action labels "
                    "and has no annotated evidence intervals or empathy judgments.")
    (ROOT / "findings.tex").write_text(summary + "\n")
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                         "axes.grid": True, "grid.alpha": .18})
    plt.figure(figsize=(5,2.1))
    y=np.arange(12); start=3
    plt.scatter(y, np.ones_like(y)*1.3, c=[COLORS[1] if start<=i<start+5 else COLORS[0] for i in y])
    plt.scatter(y, np.ones_like(y)*.7, c=[COLORS[2] if start<=i<start+5 else COLORS[0] for i in y])
    for i in range(5):
        plt.text(start+i,1.49,str(i+1),ha="center"); plt.text(start+i,.47,str(5-i),ha="center")
    plt.yticks([.7,1.3],["Reverse","Forward"]); plt.ylim(.3,1.7); plt.xticks(y); plt.xlabel("Sampled frame index")
    save("construction")
    plt.figure(figsize=(5,2.4))
    keys=["text","frame","shuffled","temporal"]
    plt.bar([MODES[k] for k in keys],[100*modes[k]["all"]["pair_accuracy"] for k in keys],color=COLORS[0])
    plt.ylabel("Correct pairs (%)"); save("pairs")
    plt.figure(figsize=(5,2.4))
    keys=["center","motion","temporal"]
    plt.bar([MODES[k] for k in keys],[100*modes[k]["all"]["mean_iou"] for k in keys],color=COLORS[1])
    plt.ylabel("Mean temporal IoU (%)"); save("spans")
    plt.figure(figsize=(5,2.4))
    for i,k in enumerate(["frame","shuffled","temporal"]):
        plt.plot(np.arange(len(metrics["history"][k]))+1,[100*r["pair_accuracy"] for r in metrics["history"][k]],
                 label=MODES[k],color=COLORS[i])
    plt.ylabel("Validation pairs (%)"); plt.xlabel("Epoch"); plt.legend(frameon=False,fontsize=8); save("learning")
    plt.figure(figsize=(5,2.4))
    plt.bar([k.replace("_"," ").title() for k in interventions],
            [100*v["pair_accuracy"] for v in interventions.values()],color=COLORS[2])
    plt.ylabel("Correct pairs (%)"); save("interventions")
    plt.figure(figsize=(5,2.4))
    plt.hist([v for r in p for v in r["iou"]],bins=np.linspace(0,1,11),color=COLORS[1])
    plt.xlabel("Temporal IoU"); plt.ylabel("Test variants"); save("distribution")
    figures=[("construction","The edited forward and reverse clips share frame content and context."),
             ("pairs","Strict paired order accuracy on the held-out split."),
             ("spans","Localization compared with center and pixel-motion heuristics."),
             ("learning","Validation pair accuracy during training."),
             ("interventions","Order predictions under input perturbations."),
             ("distribution","Distribution of temporal overlap across test variants.")]
    (ROOT / "figures.tex").write_text("".join(
        "\\begin{figure}[t]\\centering\\includegraphics[width=.95\\columnwidth]{fig/"
        + name + ".pdf}\\caption{" + caption + "}\\end{figure}\n" for name,caption in figures))
    supplement(metrics, interventions, manifest, p, dy)


def esc(s):
    return str(s).replace("_", r"\_").replace("&",r"\&").replace("%",r"\%").replace("#",r"\#")


def supplement(metrics, interventions, manifest, rows, dy):
    out = [r"""\documentclass[10pt,letterpaper]{article}
\usepackage[margin=.8in]{geometry}
\usepackage{booktabs,graphicx}
\title{En-Pathos Supplement}
\author{Anonymous}
\begin{document}
\maketitle
\section*{Artifact guide}
This supplement documents the real-footage temporal diagnostic, its development runs,
and the data needed for confirmatory supportive dialogue experiments. The accompanying
JSON files are the machine-readable source of all reported results. No original corpus
recordings are included. Paired order accuracy measures a perceptual prerequisite.
\subsection*{Contents}
Pages 2--7 reproduce main plots and their interpretation. Pages 8--15 document data,
implementation, evaluation and boundaries. Pages 16--39 list held-out predictions.
Page 40 records replication and submission checks.
"""]
    for name, intro in [("construction","Both versions use the same sampled frames. Their local ordering changes."),
                        ("pairs","An individual accuracy near chance can coexist with nonzero pair accuracy."),
                        ("spans","The pixel-motion baseline tests a shortcut made possible by compositing."),
                        ("learning","The validation trajectories use one initialization seed."),
                        ("interventions","Gray context and brightness shift test distinct perturbations."),
                        ("distribution","The histogram records the spread of overlap, including complete misses.")]:
        out.append(r"\clearpage\section*{" + name.title() + "}\n" + esc(intro)
                   + r"\begin{center}\includegraphics[width=.85\linewidth]{fig/" + name + r".pdf}\end{center}")
    detail = [
        ("Data inventory", "The executable manifest records every source group and clip. Source labels are kept distinct across corpora. The acquired corpora are local archive subsets. They were not sampled as a probability sample of either full dataset."),
        ("Split audit", "Both versions remain in the same split. MELD is grouped by episode. HMDB51 is grouped by parsed filename prefix, with the action-dependent suffix removed when present. Actor overlap can persist. No claim of actor-disjoint generalization is made."),
        ("Preprocessing", "Decode the original clip with PyAV. Uniformly sample 12 indices over decoded frame order. Convert selected frames to grayscale and resize to 24 by 24. Exclude clips with fewer than 12 decoded frames or an invalid container."),
        ("Model and training", "The frame projection is learned jointly with the temporal encoder. Candidate intervals always contain five consecutive frames. The order head uses the weighted token drift, while the source-label head uses the pooled temporal embedding. Use 16 epochs and four CPU threads."),
        ("Metrics", "Pair accuracy requires both variants to be correct. Grounded pair accuracy further requires both predicted intervals to reach 0.5 temporal IoU. For length-five intervals, overlap is five minus start error, clipped to zero. Union is ten minus overlap."),
        ("Uncertainty", "The percentile interval is computed from 2,000 bootstrap replicates. Resample source groups within each corpus and pool clip-level numerators and denominators. Fixed transcript and canonical shuffled controls produce identical inputs within each pair."),
        ("Response framework", "EPITOME motivates acknowledgment, interpretation and exploration. MITI motivates autonomy and partnership. Add tests for unsupported inference, inappropriate agreement, and video evidence. Support strategy labels alone are insufficient to evaluate perceived empathy."),
        ("Confirmatory study", "Record participants with informed consent and matched words, actor, lighting, and framing. Verify that the changed cue is visible and changes reply appropriateness. Hold out actors and scripts. Collect blinded ratings and report both span localization and response preference.")
    ]
    for title, paragraph in detail:
        out.append(r"\clearpage\section*{" + title + "}\n" + esc(paragraph) + "\n")
        if title == "Data inventory":
            for split,v in metrics["split"].items():
                out.append(r"\paragraph{" + split.title() + "} " + esc(", ".join(f"{k} {n}" for k,n in v.items())))
        if title == "Split audit":
            for split in ("train","val","test"):
                groups = Counter(s for s,g in {(r["source"],r["group"]) for r in manifest if r["split"]==split})
                out.append(r"\paragraph{" + split.title() + " groups} " + esc(dict(groups)))
        if title == "Metrics":
            for mode,v in metrics["results"].items():
                out.append(r"\paragraph{" + MODES[mode] + "} " + esc(
                    ", ".join(f"{k}: {pct(value)}" for k,value in v["all"].items() if k!="clips")))
        if title == "Uncertainty":
            for mode,v in interventions.items():
                out.append(r"\paragraph{" + esc(mode) + "} " + esc(
                    f'Pair CI {v["pair_ci95"]}. IoU CI {v["iou_ci95"]}.'))
        if title == "Confirmatory study" and dy:
            out.append(r"\paragraph{Semantic direction probe} " + esc(
                f'Train pairs {dy["train_pairs"]}. Test pairs {dy["test_pairs"]}. Grouped by source family.'))
    for index, subset in enumerate(np.array_split(np.asarray(rows,dtype=object),24),1):
        out.append(r"\clearpage\section*{Held-out predictions " + str(index) + r" of 24}" + "\n"
                   + "Every row is one source clip. Gold order is forward then reverse. "
                   + "Start indices use the 12-frame edited coordinate system.\n\n"
                   + r"\begin{tabular}{llllrr} \toprule Source & Clip & Pred. order & Start & IoU F & IoU R \\ \midrule" + "\n")
        for row in subset:
            cells=[row["source"],row["clip"],str(row["prediction"]),str(row["span"]),
                   f'{row["iou"][0]:.2f}',f'{row["iou"][1]:.2f}']
            out.append(" & ".join(esc(c) for c in cells)+r" \\")
        out.append(r"\bottomrule\end{tabular}" + "\n")
        successes=sum(all(r["correct"]) for r in subset)
        grounded=sum(all(r["correct"]) and min(r["iou"])>=.5 for r in subset)
        out.append(r"\paragraph{Panel summary} " + f"{len(subset)} source pairs, {successes} correctly ordered pairs, "
                   + f"and {grounded} grounded correct pairs. These panels partition the test manifest in its recorded order.")
    out.append(r"""\clearpage\section*{Replication and remaining evidence}
The README gives the commands for training, intervention analysis, and rebuilding the manuscript.
The checkpoint contains only learned tensors. The raw videos remain with their original providers.
For exact replication, restore source membership from the frozen manifest.
\paragraph{Evidence boundaries}
The experiment measures order, interval overlap and auxiliary class prediction.
The separate response rubric pilot used text and still images.
Video-conditioned improvement in perceived empathy requires a new dataset and independent judgments.
\end{document}
""")
    (ROOT / "supplement.tex").write_text("\n".join(out))


if __name__ == "__main__":
    main()
