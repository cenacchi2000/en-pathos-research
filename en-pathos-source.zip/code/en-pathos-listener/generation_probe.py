"""Measure reply changes on held-out video under descriptor reordering."""
import argparse
import json
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

from reply import generate
from train import EvidencePrefix


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("checkpoint", type=Path)
    ap.add_argument("turns", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--device", default="mps" if torch.backends.mps.is_available() else "cpu")
    a = ap.parse_args()
    torch.set_num_threads(4)
    tokenizer = AutoTokenizer.from_pretrained(a.base)
    backbone = AutoModelForCausalLM.from_pretrained(a.base, dtype=torch.float32).to(a.device)
    model = PeftModel.from_pretrained(backbone, a.checkpoint / "lora").eval()
    prefix = EvidencePrefix(model.config.hidden_size).to(a.device)
    prefix.load_state_dict(torch.load(a.checkpoint / "prefix.pt", weights_only=True))
    prefix.eval()
    ids = set(json.loads((a.checkpoint / "metrics.json").read_text())["test_ids"])
    predictions = []
    for row in map(json.loads, a.turns.read_text().splitlines()):
        if row["item"] not in ids or not row["video"]:
            continue
        frames = row["video"]
        versions = {"text": None, "ordered": frames,
                    "reversed_descriptors": frames[::-1],
                    "middle_descriptor": [frames[len(frames)//2]] * len(frames)}
        replies = {k: generate(model, tokenizer, prefix, row["text"], v, a.device)
                   for k, v in versions.items()}
        predictions.append({"item":row["item"], "replies":replies})
    if not predictions:
        raise ValueError("No held-out video turns")
    counts = {k: sum(r["replies"][k] != r["replies"]["ordered"] for r in predictions)
              for k in versions if k != "ordered"}
    a.output.write_text(json.dumps({"examples":len(predictions),"changed_vs_ordered":counts,
                                   "predictions":predictions},indent=2)+"\n")
    print(counts, flush=True)


if __name__ == "__main__":
    main()
