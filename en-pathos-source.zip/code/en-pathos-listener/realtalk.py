"""Create next-turn examples from RealTalk ASR and active-speaker annotations."""
import argparse
from collections import Counter
import json
from pathlib import Path

import av
import numpy as np

from data import record


def assigned_speaker(annotations, start, end):
    samples = np.linspace(start * 25, end * 25, 10, endpoint=False)
    votes = Counter(annotations.get(str(int(t)), {}).get("current_speaker") for t in samples)
    for speaker in ("p0", "p1"):
        if votes[speaker] >= 8:
            return speaker
    return None


def describe(frames):
    array = np.stack(frames)
    rgb = array.reshape(8, 4, 8, 4, 8, 3).mean((2, 4))
    delta = np.diff(array, axis=0, prepend=array[:1]).reshape(8, 4, 8, 4, 8, 3)
    return np.concatenate((rgb, np.abs(delta).mean((2, 4))), axis=-1).reshape(8, 96).tolist()


def examples(path, transcript, annotations):
    segments = transcript["segments"]
    requests = []
    for i, (a, b) in enumerate(zip(segments, segments[1:])):
        gap = b["start"] - a["end"]
        if not (-0.01 <= gap <= 2 and 1 <= a["end"] - a["start"] <= 20):
            continue
        if not a["text"].strip() or not b["text"].strip():
            continue
        speaker = assigned_speaker(annotations, a["start"], a["end"])
        listener = assigned_speaker(annotations, b["start"], b["end"])
        if speaker and listener and speaker != listener:
            requests.append((i, a, b))
    if not requests:
        return
    group = f"realtalk/{path.stem}"
    with av.open(str(path)) as container:
        stream = container.streams.video[0]
        pending = iter(requests)
        i, a, b = next(pending)
        targets = iter(np.linspace(a["start"], a["end"], 9, endpoint=False)[1:])
        target = next(targets)
        frames = []
        try:
            for frame in container.decode(stream):
                if frame.time is None or frame.time < target:
                    continue
                if frame.time < a["end"]:
                    pixels = frame.to_image().convert("RGB").resize((32, 32))
                    frames.append(np.asarray(pixels, dtype=np.float32) / 255)
                    target = next(targets, None)
                    if target is not None:
                        continue
                    yield record("realtalk", group, f"{group}/{i}", a["text"], b["text"], video=describe(frames))
                item = next(pending, None)
                if item is None:
                    break
                i, a, b = item
                targets = iter(np.linspace(a["start"], a["end"], 9, endpoint=False)[1:])
                target = next(targets)
                frames = []
        except av.FFmpegError:
            return


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--video-dir", type=Path)
    args = parser.parse_args()
    counts = Counter()
    with args.out.open("w") as out:
        for path in sorted((args.video_dir or args.root / "raw").rglob("*.avi")):
            asr = args.root / "asr" / "asr" / (path.stem + ".json")
            metadata = args.root / "annotations" / "metadata" / (path.stem + ".json")
            if not asr.is_file() or not metadata.is_file():
                continue
            try:
                transcript = json.loads(asr.read_text())
                labels = json.loads(metadata.read_text())
                if transcript["language"] != "en":
                    continue
                for row in examples(path, transcript, labels):
                    out.write(json.dumps(row, ensure_ascii=False) + "\n")
                    counts[row["split"]] += 1
            except (av.FFmpegError, json.JSONDecodeError):
                continue
    print(dict(counts))


if __name__ == "__main__":
    main()
