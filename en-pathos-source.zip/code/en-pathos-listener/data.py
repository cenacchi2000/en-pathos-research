"""Build next-reply training data with provenance and source-group isolation."""
import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import av
import numpy as np
from PIL import Image


def split(group):
    n = int(hashlib.sha256(("listener-v1/" + group).encode()).hexdigest()[:8], 16) % 100
    return "train" if n < 75 else "validation" if n < 85 else "test"


def video_features(path):
    with av.open(str(path)) as container:
        frames = [np.asarray(frame.to_image().resize((32, 32), Image.Resampling.BILINEAR),
                             dtype=np.float32) / 255 for frame in container.decode(video=0)]
    if len(frames) < 8:
        raise ValueError("Need eight decodable frames")
    frames = np.asarray(frames)[np.linspace(0, len(frames) - 1, 8).round().astype(int)]
    return sampled_frame_features(frames)


def sampled_frame_features(frames):
    patch = frames.reshape(8, 4, 8, 4, 8, 3).mean((2, 4))
    delta = np.diff(frames, axis=0, prepend=frames[:1]).reshape(8, 4, 8, 4, 8, 3)
    return np.concatenate((patch, np.abs(delta).mean((2, 4))), axis=-1).reshape(8, 96).tolist()


def record(source, group, item, text, reply, strategy="", context="", video=None):
    return dict(source=source, group=group, item=item, split=split(group),
                text=text.strip(), reply=reply.strip(), strategy=strategy,
                context=context.strip(), video=video)


def load_esconv(path):
    for index, dialogue in enumerate(json.loads(path.read_text())):
        turns = dialogue["dialog"]
        group = f"esconv/{index}"
        for i, (a, b) in enumerate(zip(turns, turns[1:])):
            if (a["speaker"], b["speaker"]) == ("seeker", "supporter"):
                yield record("esconv", group, f"{group}/{i}", a["content"], b["content"],
                             b["annotation"].get("strategy", ""))


def load_mesc(root):
    with (root / "MESC.csv").open(encoding="utf-8-sig", newline="") as handle:
        originals = defaultdict(list)
        for row in csv.DictReader(handle):
            originals[row["Dialogue_ID"]].append(row)
    by_length = defaultdict(list)
    for key, rows in originals.items():
        by_length[len(rows)].append((key, rows))
    seen = set()
    for part in ("train", "val", "test"):
        for dialogue in json.loads((root / f"mesc-{part}.json").read_text()):
            turns = dialogue["dialog"]
            matches = [(key, rows) for key, rows in by_length[len(turns)]
                       if all(t["text"].strip().startswith(r["Utterance"].strip()) for t, r in zip(turns, rows))]
            if len(matches) != 1:
                continue
            key, rows = matches[0]
            if key in seen:
                continue
            seen.add(key)
            group = f'mesc/{rows[0]["Season"]}/{rows[0]["Episode"]}'
            for i, (a, b) in enumerate(zip(turns, turns[1:])):
                if (a["speaker"], b["speaker"]) == ("user", "sys") and b.get("strategy"):
                    text = rows[i]["Utterance"].strip()
                    yield record("mesc", group, f"mesc/{key}/{i}", text, rows[i+1]["Utterance"],
                                 b["strategy"], a["text"].strip()[len(text):])


def load_annomi(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        conversations = defaultdict(list)
        for row in csv.DictReader(handle):
            if row["mi_quality"] == "high":
                conversations[row["transcript_id"]].append(row)
    for rows in conversations.values():
        rows.sort(key=lambda row: int(row["utterance_id"]))
        group = "annomi/" + hashlib.sha256(rows[0]["video_url"].encode()).hexdigest()[:16]
        for a, b in zip(rows, rows[1:]):
            if (a["interlocutor"], b["interlocutor"]) == ("client", "therapist"):
                yield record("annomi", group, f'annomi/{a["transcript_id"]}/{a["utterance_id"]}',
                             a["utterance_text"], b["utterance_text"], b["main_therapist_behaviour"])


def load_meld(annotations, media):
    with annotations.open(encoding="utf-8-sig", errors="replace", newline="") as handle:
        rows = {(int(r["Dialogue_ID"]), int(r["Utterance_ID"])): r for r in csv.DictReader(handle)}
    for (dialogue, turn), a in sorted(rows.items()):
        b = rows.get((dialogue, turn + 1))
        path = media / f"dia{dialogue}_utt{turn}.mp4"
        if not b or a["Speaker"] == b["Speaker"] or not path.is_file():
            continue
        try:
            video = video_features(path)
        except (av.FFmpegError, OSError, ValueError):
            continue
        group = f'meld/{a["Season"]}/{a["Episode"]}'
        yield record("meld", group, f"meld/{dialogue}/{turn}", a["Utterance"], b["Utterance"], video=video)


def load_authorized(path):
    """Use turn-aligned local records from approved speaker–listener releases."""
    for line in path.read_text().splitlines():
        row = json.loads(line)
        source = row["source"]
        if source in {"meld", "mesc", "esconv", "annomi"}:
            raise ValueError("Use a unique source identifier for imported footage.")
        group = source + "/" + row["group"]
        yield record(source, group, source + "/" + row["item"], row["text"], row["reply"],
                     row.get("strategy", ""), video=video_features(path.parent / row["video"]))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("strategy_data", type=Path)
    parser.add_argument("annomi", type=Path)
    parser.add_argument("meld_annotations", type=Path)
    parser.add_argument("meld_media", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--authorized", type=Path)
    args = parser.parse_args()
    sources = [load_esconv(args.strategy_data / "ESConv.json"), load_mesc(args.strategy_data),
               load_annomi(args.annomi), load_meld(args.meld_annotations, args.meld_media)]
    if args.authorized:
        sources.append(load_authorized(args.authorized))
    counts = defaultdict(int)
    with args.output.open("w") as handle:
        for source in sources:
            for row in source:
                if row["text"] and row["reply"]:
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                    counts[row["source"], row["split"]] += 1
    print(dict(counts), flush=True)


if __name__ == "__main__":
    main()
