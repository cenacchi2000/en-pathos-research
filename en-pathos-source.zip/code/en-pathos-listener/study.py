"""Prepare blinded video/reply packets and analyze paired human ratings."""
import argparse
import csv
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random

import numpy as np


def read(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def blind(manifest, output):
    inputs = read(manifest)
    variants = defaultdict(dict)
    for row in inputs:
        key = row["pair"], row["variant"]
        if row["variant"] not in {"original", "swap", "nuisance"} or key[1] in variants[key[0]]:
            raise ValueError("Invalid or duplicate variant")
        if not all(row[k].strip() for k in ("speaker", "transcript", "clip", "baseline_reply", "model_reply")):
            raise ValueError("Each item requires a speaker, transcript, clip and both replies")
        variants[key[0]][key[1]] = row
    if not variants:
        raise ValueError("No stimuli provided")
    for group in variants.values():
        if set(group) != {"original","swap","nuisance"}:
            raise ValueError("Every pair requires original, swap and nuisance variants")
        if len({(r["speaker"], r["transcript"].strip()) for r in group.values()}) != 1:
            raise ValueError("Speaker and transcript must match within a pair")
        if len({r["clip"] for r in group.values()}) != 3:
            raise ValueError("Supply three distinct clips")
    output.mkdir(parents=True, exist_ok=True)
    rng = random.Random(42)
    key, ratings = [], []
    for row in inputs:
        tag = hashlib.sha256((row["pair"]+"/"+row["variant"]).encode()).hexdigest()[:20]
        model_left = rng.choice((True,False))
        names = ["model_reply","baseline_reply"] if model_left else ["baseline_reply","model_reply"]
        key.append(dict(item=tag, pair=row["pair"], speaker=row["speaker"], variant=row["variant"],
                        model_side="a" if model_left else "b"))
        ratings.append(dict(item=tag, clip=row["clip"], transcript=row["transcript"], a=row[names[0]],
                            b=row[names[1]], rater="", a_empathy="", b_empathy="",
                            a_cue_fit="", b_cue_fit="", a_unsupported="", b_unsupported=""))
    rng.shuffle(ratings)
    write(output/"ratings.csv", ratings)
    write(output/"private-key.csv", key)


def analyze(ratings, key):
    mapping = {r["item"]:r for r in read(key)}
    data = defaultdict(list)
    seen = set()
    for row in read(ratings):
        item = row["item"]
        who = row["rater"]
        if not who.strip() or (item,who) in seen:
            raise ValueError("Each rated item requires a unique rater")
        seen.add((item,who))
        ref = mapping[item]
        model = ref["model_side"]
        base = "b" if model=="a" else "a"
        values = []
        for measure in ("empathy","cue_fit","unsupported"):
            a,b = [int(row[f"{side}_{measure}"]) for side in (model,base)]
            valid = (0,1) if measure=="unsupported" else (1,2,3,4,5)
            if a not in valid or b not in valid:
                raise ValueError("Rating out of range")
            values.append(a-b)
        data[item].append(values)
    if set(data)!=set(mapping) or min(map(len,data.values()), default=0)<3:
        raise ValueError("Every item needs at least three independent ratings")
    speakers = defaultdict(lambda: defaultdict(list))
    for item, values in data.items():
        r=mapping[item]
        speakers[r["speaker"]][r["variant"]].append(np.mean(values,axis=0))
    matrix = np.array([[np.mean(x[v],axis=0) for v in ("original","swap","nuisance")]
                       for x in speakers.values()])
    rng=np.random.default_rng(42)
    draws=rng.integers(0,len(matrix),(10000,len(matrix)))
    def interval(values):
        return {"mean":float(values.mean()),"ci95":np.percentile(values[draws].mean(1),[2.5,97.5]).tolist()}
    return {"speakers":len(matrix),"ratings":len(seen),
            "primary_swap_empathy_gain":interval(matrix[:,1,0]),
            "swap_cue_fit_gain":interval(matrix[:,1,1]),
            "swap_unsupported_difference":interval(matrix[:,1,2]),
            "nuisance_minus_original_empathy_gain":interval(matrix[:,2,0]-matrix[:,0,0])}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("command",choices=["blind","analyze"])
    ap.add_argument("first",type=Path)
    ap.add_argument("second",type=Path)
    args=ap.parse_args()
    if args.command=="blind":
        blind(args.first,args.second)
    else:
        print(json.dumps(analyze(args.first,args.second),indent=2))


if __name__=="__main__":
    main()
