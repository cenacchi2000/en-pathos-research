"""Generate matched base and adapted replies for consented study footage."""
import argparse
import csv
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

from data import video_features
from train import EvidencePrefix, prompt


def generate(model, tokenizer, prefix, text, video, device, *, max_prompt_tokens=96, max_new_tokens=48):
    token_ids = prompt(tokenizer, text)
    if max_prompt_tokens is not None:
        token_ids = token_ids[-max_prompt_tokens:]
    tokens = torch.tensor([token_ids], device=device)
    inputs = model.get_input_embeddings()(tokens)
    if video is not None:
        visual = prefix(torch.tensor([video], dtype=torch.float32, device=device))
        inputs = torch.cat((visual.to(inputs.dtype), inputs), dim=1)
    mask = torch.ones(inputs.shape[:2], device=device, dtype=torch.long)
    with torch.no_grad():
        output = model.generate(inputs_embeds=inputs, attention_mask=mask, max_new_tokens=max_new_tokens,
                                do_sample=False, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(output[0], skip_special_tokens=True).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("checkpoint", type=Path)
    ap.add_argument("stimuli", type=Path, help="CSV with pair, variant, speaker, transcript, clip")
    ap.add_argument("out", type=Path)
    ap.add_argument("--device", default="mps" if torch.backends.mps.is_available() else "cpu")
    ap.add_argument("--baseline", choices=["base-text","tuned-text","frame","shuffled"], default="tuned-text")
    args = ap.parse_args()
    torch.set_num_threads(4)
    tokenizer = AutoTokenizer.from_pretrained(args.base)
    model = AutoModelForCausalLM.from_pretrained(args.base, dtype=torch.float32).to(args.device)
    model = PeftModel.from_pretrained(model, args.checkpoint/"lora").eval()
    prefix = EvidencePrefix(model.config.hidden_size).to(args.device)
    prefix.load_state_dict(torch.load(args.checkpoint/"prefix.pt", weights_only=True))
    prefix.eval()
    with args.stimuli.open(newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        video = video_features(args.stimuli.parent/row["clip"])
        row["model_reply"] = generate(model,tokenizer,prefix,row["transcript"],video,args.device)
        control = None
        if args.baseline == "frame":
            control = [video[len(video)//2]]*len(video)
        elif args.baseline == "shuffled":
            control = [video[i] for i in (2,6,0,5,3,7,1,4)]
        if args.baseline == "base-text":
            with model.disable_adapter():
                row["baseline_reply"] = generate(model,tokenizer,prefix,row["transcript"],None,args.device)
        else:
            row["baseline_reply"] = generate(model,tokenizer,prefix,row["transcript"],control,args.device)
    with args.out.open("w", newline="") as f:
        writer=csv.DictWriter(f,fieldnames=["pair","variant","speaker","transcript","clip",
                                            "baseline_reply","model_reply"])
        writer.writeheader()
        writer.writerows(rows)


if __name__=="__main__":
    main()
