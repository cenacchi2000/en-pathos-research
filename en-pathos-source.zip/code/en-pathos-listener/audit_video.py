"""Audit real footage training manifests before calling the reply trainer."""
import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path


def audit(path):
    counts = defaultdict(Counter)
    groups = defaultdict(set)
    splits = {}
    items = set()
    with path.open() as rows:
        for n, line in enumerate(rows, 1):
            row = json.loads(line)
            source, group, item, split = (row[k] for k in ("source", "group", "item", "split"))
            if split not in {"train", "validation", "test"}:
                raise ValueError(f"Invalid split on line {n}")
            if (source, item) in items or splits.setdefault((source, group), split) != split:
                raise ValueError(f"Duplicate item or group crosses splits on line {n}")
            items.add((source, item))
            video = row["video"]
            if video is None:
                counts[source][f"{split}_no_video"] += 1
                continue
            if len(video) != 8 or any(len(f) != 96 or any(not math.isfinite(x) for x in f) for f in video):
                raise ValueError(f"Expected eight finite 96-D frame descriptors on line {n}")
            counts[source][f"{split}_video"] += 1
            groups[source, split].add(group)
    for (source, split), identifiers in groups.items():
        counts[source][f"{split}_video_groups"] = len(identifiers)
    return {source: dict(data) for source, data in sorted(counts.items())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--require", nargs="+", default=[])
    parser.add_argument("--min-train-video", type=int, default=1000)
    parser.add_argument("--min-test-video", type=int, default=100)
    args = parser.parse_args()
    report = audit(args.manifest)
    print(json.dumps(report, indent=2))
    missing = [
        src for src in args.require if report.get(src, {}).get("train_video", 0) < args.min_train_video
        or report.get(src, {}).get("test_video", 0) < args.min_test_video
    ]
    if missing:
        parser.exit(2, "Insufficient video coverage: " + ", ".join(missing) + "\n")


if __name__ == "__main__":
    main()
