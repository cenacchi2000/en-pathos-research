"""Write the paper's result table from completed matched runs."""
import argparse
import json
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mixed", type=Path)
    ap.add_argument("text", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    mixed, text = [json.loads(p.read_text()) for p in (args.mixed, args.text)]
    for field in ("train_ids", "test_ids"):
        if mixed[field] != text[field]:
            raise ValueError(f"Matched training controls disagree on {field}")
    if mixed["text_only_training"] or not text["text_only_training"]:
        raise ValueError("Unexpected training condition")
    lines = [
        "Both adaptations used 1,536 training turns and one epoch. There were 482 turns from each of ESConv, AnnoMI and MESC, and 90 MELD turns. The test set included 40 turns from each transcript corpus and eight MELD video turns. Perplexity is the exponential of mean reply-token negative log likelihood.",
        r"\begin{table}[t]\centering\small",
        r"\caption{Held-out reply-token perplexity. Lower is better. The video column uses the same eight MELD turns for each condition.}",
        r"\begin{tabular}{lrr}\toprule Condition & All & MELD \\\midrule",
    ]
    entries = [
        ("Frozen, text", mixed["base_text"]["all"], mixed["base_text"]["meld"]),
        ("Text-trained, text", text["tuned_text"]["all"], text["tuned_text"]["meld"]),
        ("Mixed-trained, text", mixed["tuned_text"]["all"], mixed["video_text"]["all"]),
        ("Mixed-trained, available context", mixed["tuned_full"]["all"], mixed["video_full"]["all"]),
        ("Mixed-trained, middle frame", None, mixed["video_frame"]["all"]),
        ("Mixed-trained, shuffled descriptors", None, mixed["video_shuffled"]["all"]),
    ]
    def number(value):
        return "--" if value is None else f'{value["perplexity"]:.2f}'
    lines.extend(f"{label} & {number(all_rows)} & {number(video)} " + r"\\" for label, all_rows, video in entries)
    lines.append(r"\bottomrule\end{tabular}\end{table}")
    lines.append(
        f'On MELD, ordered video changed perplexity from {number(mixed["video_text"]["all"])} with text '
        f'to {number(mixed["video_full"]["all"])}. Frame and shuffle controls were close to the ordered condition. '
        'This run provides no evidence of a reply-likelihood improvement from visual input.'
    )
    args.output.write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
