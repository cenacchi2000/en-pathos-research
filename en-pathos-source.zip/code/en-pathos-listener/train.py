"""Fine-tune a reply generator with a trainable temporal prefix and LoRA."""
import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import random

import torch
from torch import nn
from torch.nn import functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig, get_peft_model

PREFIX = 8
SYSTEM = ("Reply supportively to the user. Use concrete details, respect their preference "
          "for listening or advice, and qualify uncertain interpretations.")


class EvidencePrefix(nn.Module):
    def __init__(self, hidden):
        super().__init__()
        self.project = nn.Linear(96, 96)
        self.temporal = nn.Conv1d(96, 96, 3, padding=1)
        self.output = nn.Sequential(nn.LayerNorm(96), nn.Linear(96, hidden))
        self.position = nn.Parameter(torch.zeros(1, PREFIX, 96))

    def forward(self, frames):
        x = self.project(frames) + self.position
        return self.output(x + F.gelu(self.temporal(x.transpose(1, 2)).transpose(1, 2))) * .05


def prompt(tokenizer, text, context=""):
    message = text if not context else f"{text}\nObservable context: {context}"
    return tokenizer.apply_chat_template([{"role": "system", "content": SYSTEM},
        {"role": "user", "content": message}], tokenize=True, add_generation_prompt=True)


def select(rows, limit, rng):
    strata = defaultdict(list)
    for row in rows:
        strata[row["source"]].append(row)
    for group in strata.values():
        rng.shuffle(group)
    result = []
    while len(result) < limit and any(strata.values()):
        for group in strata.values():
            if group and len(result) < limit:
                result.append(group.pop())
    rng.shuffle(result)
    return result


def collate(rows, tokenizer, device, mode):
    tokens, gold, features, masks = [], [], [], []
    for row in rows:
        p = prompt(tokenizer, row["text"], row["context"] if mode == "full" else "")[-96:]
        r = tokenizer(row["reply"], add_special_tokens=False)["input_ids"][:48] + [tokenizer.eos_token_id]
        tokens.append(p+r)
        gold.append([-100]*len(p)+r)
        video = row["video"] if mode in {"full", "frame", "shuffled"} else None
        if video and mode == "frame":
            video = [video[len(video)//2]]*PREFIX
        if video and mode == "shuffled":
            video = [video[i] for i in (2, 6, 0, 5, 3, 7, 1, 4)]
        features.append(video if video else [[0.]*96]*PREFIX)
        masks.append([bool(video)]*PREFIX)
    longest = max(map(len, tokens))
    pad = lambda rows, n: [row + [n]*(longest-len(row)) for row in rows]
    ids = torch.tensor(pad(tokens, tokenizer.pad_token_id), device=device)
    labels = torch.tensor(pad(gold, -100), device=device)
    attn = torch.tensor(pad([[1]*len(t) for t in tokens], 0), device=device)
    return ids, labels, attn, torch.tensor(features, device=device), torch.tensor(masks, device=device)


def forward(model, prefix, batch):
    ids, gold, attn, video, mask = batch
    embeddings = model.get_input_embeddings()(ids)
    if mask.any():
        visual = prefix(video).to(embeddings.dtype) * mask.unsqueeze(-1)
        embeddings = torch.cat((visual, embeddings), dim=1)
        attn = torch.cat((mask.long(), attn), dim=1)
        gold = F.pad(gold, (PREFIX, 0), value=-100)
    positions = (attn.cumsum(-1)-1).clamp(min=0)
    output = model(inputs_embeds=embeddings, attention_mask=attn, position_ids=positions,
                   labels=gold, use_cache=False)
    return output.loss, int((gold != -100).sum().item())


def evaluate(model, prefix, tokenizer, rows, device, mode):
    totals = defaultdict(lambda: [0.,0])
    model.eval()
    prefix.eval()
    with torch.no_grad():
        for i in range(0, len(rows), 4):
            chunk = rows[i:i+4]
            for row in chunk:
                loss, count = forward(model, prefix, collate([row], tokenizer, device, mode))
                for key in ("all", row["source"]):
                    totals[key][0] += loss.item()*count
                    totals[key][1] += count
    return {k: {"tokens": n, "nll": total/n, "perplexity": math.exp(total/n)}
            for k,(total,n) in totals.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("data", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--train-examples", type=int, default=384)
    ap.add_argument("--eval-examples", type=int, default=64)
    ap.add_argument("--text-only-training", action="store_true")
    ap.add_argument("--retain-training-video", action="store_true",
                    help="Always present video on batches that contain clips.")
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--device", default="mps" if torch.backends.mps.is_available() else "cpu")
    args = ap.parse_args()
    torch.set_num_threads(4)
    torch.manual_seed(42)
    rng = random.Random(42)
    rows = [json.loads(line) for line in args.data.read_text().splitlines()]
    train = select([r for r in rows if r["split"]=="train"], args.train_examples, rng)
    test = select([r for r in rows if r["split"]=="test"], args.eval_examples, rng)
    args.out.mkdir(parents=True, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(args.base)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    base = AutoModelForCausalLM.from_pretrained(args.base, dtype=torch.float32).to(args.device)
    prefix = EvidencePrefix(base.config.hidden_size).to(args.device)
    report = {"base": Path(args.base).name, "device": args.device, "epochs": args.epochs,
              "text_only_training": args.text_only_training,
              "retain_training_video": args.retain_training_video,
              "raw_video_train_counts": dict(Counter(r["source"] for r in train if r["video"] is not None)),
              "train_counts": dict(Counter(r["source"] for r in train)),
              "test_counts": dict(Counter(r["source"] for r in test)),
              "train_ids": [r["item"] for r in train], "test_ids": [r["item"] for r in test]}
    report["base_text"] = evaluate(base, prefix, tokenizer, test, args.device, "text")
    print("base evaluated", report["base_text"], flush=True)
    model = get_peft_model(base, LoraConfig(r=8, lora_alpha=16, target_modules=["q_proj", "v_proj"],
                                          task_type="CAUSAL_LM"))
    opt = torch.optim.AdamW([p for p in [*model.parameters(), *prefix.parameters()] if p.requires_grad],
                            lr=2e-4)
    log = []
    for epoch in range(args.epochs):
        model.train()
        prefix.train()
        rng.shuffle(train)
        for i in range(0, len(train), 4):
            batch = train[i:i+4]
            # Deterministic modality dropout retains a usable transcript-only path.
            keep_context = rng.random() > .20
            if args.retain_training_video and any(row["video"] is not None for row in batch):
                keep_context = True
            mode = "full" if keep_context and not args.text_only_training else "text"
            loss, count = forward(model, prefix, collate(batch, tokenizer, args.device, mode))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_([p for p in [*model.parameters(), *prefix.parameters()]
                                           if p.requires_grad], 1.0)
            opt.step()
            log.append(loss.item())
            if len(log) % 20 == 0:
                print("step", len(log), "loss", round(sum(log[-20:])/20, 3), flush=True)
    model.save_pretrained(args.out / "lora")
    torch.save(prefix.state_dict(), args.out / "prefix.pt")
    report["train_loss"] = log
    for mode in ("text", "full"):
        report["tuned_"+mode] = evaluate(model, prefix, tokenizer, test, args.device, mode)
    visual_test = [r for r in test if r["video"]]
    if visual_test:
        for mode in ("text", "full", "frame", "shuffled"):
            report["video_"+mode] = evaluate(model, prefix, tokenizer, visual_test, args.device, mode)
    (args.out / "metrics.json").write_text(json.dumps(report, indent=2) + "\n")
    print({k:v for k,v in report.items() if not k.endswith(("ids","loss"))}, flush=True)


if __name__ == "__main__":
    main()
