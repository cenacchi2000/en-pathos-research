"""Load the trained preference scorer for reply generation."""
from functools import lru_cache
import json
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from .fit import features


@lru_cache(maxsize=1)
def load():
    path = Path(__file__).with_name("weights.json")
    data = json.loads(path.read_text())
    vectorizer = TfidfVectorizer(vocabulary=data["vocabulary"], ngram_range=(1, 2), sublinear_tf=True)
    vectorizer.idf_ = np.asarray(data["idf"])
    return vectorizer, np.asarray(data["coefficients"])


def scores(message, replies):
    vectorizer, coefficients = load()
    return features(vectorizer, [message] * len(replies), replies) @ coefficients
