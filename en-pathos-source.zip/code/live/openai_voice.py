"""Render a finished assistant reply using OpenAI Realtime audio."""
import base64
import io
import json
import os
import wave
import subprocess
import sys
import time
from pathlib import Path


def voice_key():
    key = os.environ.get("OPENAI_API_KEY")
    if key or sys.platform != "darwin":
        return key
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-s", "en-pathos-openai-voice",
             "-a", Path.home().name, "-w"], text=True, capture_output=True, timeout=3,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    return result.stdout.strip() if result.returncode == 0 else None


def render_voice(reply):
    key = voice_key()
    if not key:
        return None

    from websockets.sync.client import connect

    with connect(
        "wss://api.openai.com/v1/realtime?model=gpt-realtime-2.1-mini",
        additional_headers={"Authorization": f"Bearer {key}"},
        open_timeout=8,
        close_timeout=1,
    ) as ws:
        ws.send(json.dumps({
            "type": "response.create",
            "response": {
                "conversation": "none",
                "output_modalities": ["audio"],
                "audio": {"output": {"voice": "marin", "format": {"type": "audio/pcm", "rate": 24000}}},
                "instructions": (
                    "Read the supplied assistant reply verbatim. Speak warmly and plainly at an unhurried "
                    "pace, with a brief natural pause between sentences. Add no words, sounds, or commentary."
                ),
                "input": [{"type": "message", "role": "user",
                           "content": [{"type": "input_text", "text": reply}]}],
            },
        }))
        chunks = []
        deadline = time.monotonic() + 20
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("OpenAI voice timed out.")
            event = json.loads(ws.recv(timeout=remaining))
            if event["type"] == "response.output_audio.delta":
                chunks.append(base64.b64decode(event["delta"]))
            elif event["type"] == "response.done":
                if event["response"]["status"] != "completed" or not chunks:
                    raise RuntimeError("OpenAI voice did not complete.")
                break
            elif event["type"] == "error":
                raise RuntimeError("OpenAI voice request failed.")

    output = io.BytesIO()
    with wave.open(output, "wb") as wav:
        wav.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
        wav.writeframes(b"".join(chunks))
    return base64.b64encode(output.getvalue()).decode()
