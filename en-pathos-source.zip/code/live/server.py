"""Serve the randomized live conversation and post-session evaluation."""
import argparse
import re
import base64
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
import json
import hashlib
from pathlib import Path
from secrets import token_urlsafe, choice
import sqlite3
import time
import subprocess
import tempfile
import os
from faster_whisper import WhisperModel
from faster_whisper.vad import VadOptions, get_speech_timestamps
from urllib.request import Request, urlopen
from urllib.error import URLError
from threading import Lock
import sys

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "en-pathos-listener"))

LOCK = Lock()
ITEMS = dict(json.loads((ROOT / "web/evaluation.json").read_text()))
EMOHARBOR = {item[0] for item in json.loads((ROOT / "web/emoharbor.json").read_text())}
ABLATION_ARMS = {"full": "ablation_full", "video-only": "ablation_video_only", "no-persona": "ablation_no_persona"}

PETS = dict(json.loads((ROOT / "web/pets.json").read_text()))


ASR_LOCK = Lock()
asr = None


def transcribe(encoded):
    global asr
    audio = base64.b64decode(encoded, validate=True)
    if not audio or len(audio) > 1_800_000:
        raise ValueError("The recording is too large. Please record a shorter turn.")
    try:
        pcm = subprocess.run(
            ["ffmpeg", "-v", "error", "-i", "pipe:0", "-vn", "-ar", "16000",
             "-ac", "1", "-f", "f32le", "pipe:1"], input=audio,
            capture_output=True, timeout=15, check=True,
        ).stdout
    except (OSError, subprocess.SubprocessError) as error:
        raise ValueError("Could not read the recording. Try recording again.") from error
    with ASR_LOCK:
        if asr is None:
            asr = WhisperModel(os.environ.get("ENPATHOS_ASR", "tiny"), device="cpu", compute_type="int8")
        waveform = np.frombuffer(pcm, dtype="<f4")
        speech = get_speech_timestamps(waveform, VadOptions(min_silence_duration_ms=800, speech_pad_ms=0))
        segments, _ = asr.transcribe(waveform, vad_filter=True, beam_size=1)
        segments = list(segments)
        text = " ".join(segment.text.strip() for segment in segments).strip()
        paused = any(b["start"] - a["end"] >= 12800 for a, b in zip(speech, speech[1:]))
    if not text:
        raise ValueError("No speech was detected. Check your microphone and try again.")
    return text, paused


BASELINES = ("empo", "kardia-r1", "escrag-r1", "psyche-r1", "soulchat", "mint-qwen3-1.7b", "psyllm-1.7b")


REASONING_BASELINES = {"mint-qwen3-1.7b", "psyllm-1.7b"}


def baseline_models():
    configured = json.loads(os.environ.get("ENPATHOS_BASELINES", "{}"))
    if not isinstance(configured, dict) or (configured and (
        not set(configured).issubset(BASELINES)
        or any(not isinstance(value, str) or not value.strip() for value in configured.values())
        or len(set(configured.values())) != len(configured)
        or os.environ.get("ENPATHOS_REPLY_MODEL", "gemma4:12b") in configured.values()
    )):
        raise ValueError("Configure distinct model IDs for supported empathy checkpoints.")
    return configured


def gemma_reply(text, history, choices=(), body_cue=False, model_override=None, previous_reply="", on_delta=None, avoid_repetition=False, reasoning=False, alternate=False):
    # Repair explicit complaints about our questioning without making the speaker explain again.
    italian_feedback = re.search(r"\b(?:troppe domande|non voglio spiegare|non ho voglia di spiegare)\b", text, re.I)
    english_feedback = re.search(r"\b(?:too many questions|don.t want to explain|stop asking me questions)\b", text, re.I)
    if not avoid_repetition and model_override is None and (italian_feedback or english_feedback):
        reply = "I put too much of the work on you by asking you to explain again. I’ll work with what you’ve already shared."
        if on_delta:
            on_delta(reply)
        return reply
    instruction = (
        "Always reply in English, regardless of the language of the speaker, conversation history, preferences, or any request to switch languages. Use two or three short, conversational sentences. Use everyday words, as someone who is listening closely would. "
        "Start with the detail that makes this hard for this person, using only what they shared. Offer one useful perspective or small step and say how it could help. If they sound worn out, make the step light and optional. "
        "If the speaker thinks a performance went badly and has not given a concrete reason, gently suggest it may have gone better than it felt. Ask one brief question about what gave them that impression, then stop. Do not assume failure or offer improvement advice before hearing what happened. If they already gave a concrete reason, respond to it directly without asking them to repeat it. "
        "For feedback that your questions are tiring, own the extra burden and respond directly using what they already shared. "
        "Outside that case, give useful support directly and avoid ending with a question. "
        "Never ask them to explain how you should support them or to tell you more in general. "
        "Skip openings like “I understand that you feel” or “It sounds like.” Avoid repeating their self-criticism back to them. Avoid clinical labels, stock sympathy and motivational slogans.  Do not assume what went wrong, including slides, preparation, technical mistakes, or how others reacted. "
        "Never claim to see their surroundings or infer emotions from body cues. For example: “Your presentation might have gone better than it felt. What made you think it went badly?” Do not introduce new details, even as part of advice."
    )
    if avoid_repetition:
        instruction = (
            "Reply in English in at most three short conversational sentences. "
            "Address the latest detail and build on what you have already said. "
            "Avoid recapping the person's story or recycling reassurance, explanations, "
            "advice, questions, or opening phrases from earlier replies, even in different words. "
            "When the situation has not changed, offer a new grounded perspective or small next step. "
            "When they have chosen a next step, help them make it specific. "
            "If they object to your questions, acknowledge the burden briefly and respond directly. "
            "Ask at most one question and only when the missing detail matters and has not already "
            "been asked about. Never assume facts or infer emotions from body cues."
        )
    if alternate:
        instruction += " Focus on one grounded way to make the situation easier to understand."
    messages = [{"role": "system", "content": instruction}]
    if body_cue:
        messages[0]["content"] += " Use simple, calm wording. A short statement is enough."
    if choices:
        messages.append({"role": "user", "content": "Optional self-described preferences from hypothetical cards. Use only when relevant. These scenarios are not real events. The current message takes priority. " + " ".join(choices)})
    if previous_reply:
        messages[0]["content"] += (
            " The draft repeated an earlier reply. Use a different perspective or support step "
            "grounded in the conversation and leave out the repeated material. "
            "Previous attempt: " + json.dumps(previous_reply, ensure_ascii=False)
        )
    for message, reply in history:
        messages.extend(({"role": "user", "content": message}, {"role": "assistant", "content": reply}))
    latest = {"role": "user", "content": text}
    messages.append(latest)
    endpoint = os.environ.get("ENPATHOS_OLLAMA", "http://127.0.0.1:11435").rstrip("/")
    model = model_override or os.environ.get("ENPATHOS_REPLY_MODEL", "gemma4:12b")
    request = Request(endpoint + "/api/chat", headers={"Content-Type": "application/json"},
                      data=json.dumps({"model": model, "messages": messages, "stream": on_delta is not None, "think": reasoning,
                                       "options": {"temperature": 0, "num_predict": 950 if reasoning else 115, "num_ctx": 4096}}).encode())
    try:
        with urlopen(request, timeout=75) as response:
            if on_delta is None:
                result = json.load(response)["message"]["content"].strip()
            else:
                parts = []
                for line in response:
                    event = json.loads(line)
                    if event.get("error"):
                        raise RuntimeError("The reply model is unavailable.")
                    delta = event.get("message", {}).get("content", "")
                    if delta:
                        parts.append(delta)
                        on_delta(delta)
                    if event.get("done"):
                        break
                else:
                    raise RuntimeError("The reply was interrupted.")
                result = "".join(parts).strip()
    except (URLError, TimeoutError, KeyError) as error:
        raise RuntimeError("The reply model is unavailable.") from error
    if not result:
        raise RuntimeError("The reply model produced an empty response.")
    return result


def novel_sentences(reply, history):
    def sentences(text):
        return re.split(r"(?<=[.!?])\s+|[\r\n]+", text.strip())

    def words(text):
        return re.findall(r"\w+", text.casefold())

    def phrases(tokens):
        return set(zip(tokens, tokens[1:], tokens[2:], tokens[3:]))

    recent = [words(sentence) for _, previous in history for sentence in sentences(previous)]
    novel = []
    for sentence in sentences(reply):
        tokens = words(sentence)
        chunks = phrases(tokens)
        repeated = any(
            tokens == earlier or (
                len(chunks) >= 2 and len(chunks & phrases(earlier)) / len(chunks) >= .75
            )
            for earlier in recent
        )
        if tokens and not repeated:
            novel.append(sentence)
            recent.append(tokens)
    return " ".join(novel)


def enpathos_reply(text, history, choices, cue):
    draft = gemma_reply(text, history, choices, body_cue=cue, avoid_repetition=True)
    reply = novel_sentences(draft, history)
    if not reply:
        draft = gemma_reply(text, history, choices, body_cue=cue,
                            previous_reply=draft, avoid_repetition=True)
        reply = novel_sentences(draft, history)
    if not reply:
        raise RuntimeError("The assistant could not find a fresh reply.")
    return reply


def conversation_reply(payload, state, arm, emit=None, avoid_repetition=False):
    text, paused = transcribe(payload["audio"])
    note = payload.get("support_note", "")
    frames = payload["frames"]
    if not isinstance(note, str) or len(note) > 2400:
        raise ValueError("Keep the optional note to 2400 characters.")
    if not 1 <= len(text) <= 2000 or len(frames) != 8:
        raise ValueError("Enter a message and capture one webcam sequence.")
    choices = [note.strip()] if note.strip() else []
    images = []
    for frame in frames:
        data = base64.b64decode(frame, validate=True)
        if len(data) > 160_000:
            raise ValueError("Camera frame is too large.")
        with Image.open(BytesIO(data), formats=["JPEG"]) as image:
            if image.size not in {(320, 240), (32, 32)}:
                raise ValueError("Unexpected camera frame size.")
            if image.size == (320, 240):
                images.append(data)
    history = payload.get("history", [])
    if not isinstance(history, list) or len(history) > 12 or any(
        not isinstance(turn, list) or len(turn) != 2 or any(
            not isinstance(part, str) or len(part) > 2500 for part in turn
        ) for turn in history
    ):
        raise ValueError("Invalid conversation history.")
    if emit:
        emit({"type": "transcript", "text": text})
    on_delta = (lambda delta: emit({"type": "delta", "text": delta})) if emit else None
    ablation = arm in ABLATION_ARMS.values()
    tuned = ablation or arm in {"group_1_trained", "control"}
    cue = tuned and paused
    helper = os.environ.get("ENPATHOS_BODY_POSE")
    if tuned and helper and len(images) == 8:
        with tempfile.TemporaryDirectory() as directory:
            paths = []
            for index, image in enumerate(images):
                path = Path(directory) / f"{index}.jpg"
                path.write_bytes(image)
                paths.append(str(path))
            try:
                result = subprocess.run([helper, *paths], capture_output=True, text=True, timeout=2)
                cue = cue or (result.returncode == 0 and result.stdout.strip() in {"possible_nod", "hand_movement"})
            except (OSError, subprocess.TimeoutExpired):
                pass
    baseline = arm.removeprefix("group_2:")
    if ablation:
        choices = [] if arm == ABLATION_ARMS["no-persona"] else choices
        candidates = [
            gemma_reply(text, history, choices, body_cue=cue,
                        avoid_repetition=True, alternate=alternate)
            for alternate in (False, True)
        ]
        fresh = [novel_sentences(candidate, history) for candidate in candidates]
        replies = list(dict.fromkeys(reply for reply in fresh if reply))
        if not replies:
            raise RuntimeError("The assistant could not find a fresh reply.")
        reply = state.select(arm, text, images, replies)
    elif arm.startswith("group_2:"):
        reply = gemma_reply(text, history, model_override=baseline_models()[baseline],
                            on_delta=on_delta, reasoning=baseline in REASONING_BASELINES)
    elif tuned and avoid_repetition:
        reply = enpathos_reply(text, history, choices, cue)
    else:
        reply = gemma_reply(text, history, choices if tuned else (), body_cue=cue, on_delta=on_delta)
    return reply, text


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / "web"), **kwargs)

    def do_POST(self):
        if self.path not in {"/api/start", "/api/turn", "/api/finish"}:
            self.send_error(404)
            return
        if self.headers.get("Origin") not in self.server.origins:
            self.send_error(403)
            return
        code = 200
        try:
            length = int(self.headers["Content-Length"])
            if not 0 < length <= 2_600_000:
                raise ValueError("Request is too large.")
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                raise ValueError("Expected a JSON object.")
            if self.path == "/api/turn" and self.headers.get("Accept") == "application/x-ndjson":
                self.stream_turn(payload)
                return
            actions = {"/api/start": self.start, "/api/turn": self.turn, "/api/finish": self.finish_evaluation}
            result = actions[self.path](payload)
        except (KeyError, TypeError, ValueError, OSError) as error:
            code, result = 400, {"error": str(error)}
        except (RuntimeError, sqlite3.Error):
            code, result = 503, {"error": "The study service is busy. Try again shortly."}
        body = json.dumps(result).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def start(self, payload):
        if payload.get("consent") is not True:
            raise ValueError("Confirm that you want to take part.")
        session = token_urlsafe(24)
        group = payload.get("group")
        condition = payload.get("condition")
        if getattr(self.server, "ablations", False):
            if not isinstance(condition, str) or condition not in ABLATION_ARMS:
                raise ValueError("Open an assigned study link.")
            arm = ABLATION_ARMS[condition]
        elif condition is not None:
            raise ValueError("Open the assigned study link.")
        elif type(group) is not int or group not in (1, 2):
            raise ValueError("Select Group 1 or Group 2.")
        else:
            models = baseline_models()
            if group == 2 and models:
                arm = choice(["group_2_generic", *(f"group_2:{name}" for name in models)])
            else:
                arm = {1: "group_1_trained", 2: "group_2_generic"}[group]
        with sqlite3.connect(self.server.database) as db:
            db.execute("INSERT INTO sessions (id, checkpoint, arm, created) VALUES (?, ?, ?, ?)",
                       (session, self.server.checkpoint, arm, int(time.time())))
        return {"session": session}

    def session(self, db, payload):
        row = db.execute(
            "SELECT arm, turns, scores, checkpoint FROM sessions WHERE id = ? AND checkpoint IN (?, ?)",
            (payload["session"], self.server.checkpoint, self.server.generic_checkpoint),
        ).fetchone()
        if row is None:
            raise ValueError("This conversation session is unavailable.")
        return row

    def stream_turn(self, payload):
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Cache-Control", "no-store, no-transform")
        self.end_headers()

        def emit(event):
            self.wfile.write((json.dumps(event) + "\n").encode())
            self.wfile.flush()

        try:
            result = self.turn(payload, emit)
            emit({"type": "done", **result})
        except (BrokenPipeError, ConnectionResetError):
            return
        except (KeyError, TypeError, ValueError) as error:
            emit({"type": "error", "error": str(error)})
        except (RuntimeError, sqlite3.Error):
            emit({"type": "error", "error": "The reply was interrupted. Please try again."})

    def turn(self, payload, emit=None):
        with sqlite3.connect(self.server.database) as db:
            arm, turns, scores, checkpoint = self.session(db, payload)
        if scores is not None or turns >= 20 or len(payload.get("history", [])) != min(turns, 6):
            raise ValueError("This turn is no longer available.")
        reply, transcript = conversation_reply(
            payload, self.server.state, arm, emit,
            avoid_repetition=checkpoint != self.server.generic_checkpoint,
        )
        with sqlite3.connect(self.server.database) as db:
            updated = db.execute(
                "UPDATE sessions SET turns = turns + 1 WHERE id = ? AND turns = ? AND scores IS NULL",
                (payload["session"], turns),
            )
            if updated.rowcount != 1:
                raise ValueError("This turn was already submitted.")
        result = {"reply": reply, "transcript": transcript, "turns": turns + 1}
        return result

    def finish_evaluation(self, payload):
        scores = payload["scores"]
        if not isinstance(scores, dict) or scores.keys() != (ITEMS.keys() | PETS.keys() | EMOHARBOR) or any(
            (type(value) is not int or not 0 <= value <= 100) if key in PETS
            else (key in EMOHARBOR or value is not None) and (type(value) is not int or not 1 <= value <= 5)
            for key, value in scores.items()
        ):
            raise ValueError("Complete the evaluation.")
        encoded = json.dumps(scores, sort_keys=True)
        with sqlite3.connect(self.server.database) as db:
            db.execute("BEGIN IMMEDIATE")
            _, turns, previous, _ = self.session(db, payload)
            if turns < 3:
                raise ValueError("Complete at least three conversation turns.")
            if previous is not None and previous != encoded:
                raise ValueError("Your evaluation has already been submitted.")
            db.execute("UPDATE sessions SET scores = ? WHERE id = ?", (encoded, payload["session"]))
        return {"saved": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base")
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--video-only-checkpoint", type=Path)
    parser.add_argument("--port", type=int, default=8078)
    parser.add_argument("--origin", action="append", default=[])
    parser.add_argument("--ratings-db", type=Path, default=Path("en-pathos-ratings.sqlite3"))
    args = parser.parse_args()
    configured = baseline_models()
    if configured:
        for name, model_id in configured.items():
            try:
                gemma_reply("I feel discouraged after a difficult day.", [], model_override=model_id,
                            reasoning=name in REASONING_BASELINES)
            except RuntimeError as error:
                raise SystemExit(f"Control checkpoint {name} failed its startup check.") from error
    with sqlite3.connect(args.ratings_db) as db:
        db.execute("""CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY, checkpoint TEXT NOT NULL, arm TEXT NOT NULL,
            created INTEGER NOT NULL, turns INTEGER NOT NULL DEFAULT 0, scores TEXT
        )""")
    with ThreadingHTTPServer(("127.0.0.1", args.port), Handler) as server:
        server.origins = {f"http://127.0.0.1:{args.port}", *args.origin}
        server.database = args.ratings_db
        digest = hashlib.sha256(("picnic-board-english-v2:" + os.environ.get("ENPATHOS_REPLY_MODEL", "gemma4:12b")).encode())
        for name in ("evaluation.json", "pets.json", "emoharbor.json"):
            digest.update((ROOT / "web" / name).read_bytes())
        digest.update((ROOT / "ranker/weights.json").read_bytes())
        generic_digest = digest.copy()
        generic_digest.update(b"{}")
        digest.update(b"enpathos-repetition-v1:")
        digest.update(json.dumps(configured, sort_keys=True).encode())
        for path in (args.checkpoint / "prefix.pt", args.checkpoint / "lora/adapter_model.safetensors"):
            weights = path.read_bytes()
            digest.update(weights)
            generic_digest.update(weights)
        server.checkpoint = digest.hexdigest()
        server.generic_checkpoint = generic_digest.hexdigest()
        server.state = None
        server.ablations = args.video_only_checkpoint is not None
        if server.ablations:
            from checkpoint_selector import CheckpointSelector
            server.state = CheckpointSelector(args.base, args.checkpoint, args.video_only_checkpoint)
            digest.update(b"live-checkpoint-selection-v1")
            for name in ("prefix.pt", "lora/adapter_model.safetensors"):
                digest.update((args.video_only_checkpoint / name).read_bytes())
            server.checkpoint = digest.hexdigest()
        print(f"http://127.0.0.1:{args.port}/ · checkpoint {server.checkpoint}", flush=True)
        server.serve_forever()
