"""Rank Gemma's replies with the assigned, video-conditioned adapter."""
from io import BytesIO
from threading import Lock

import numpy as np
import torch
from peft import PeftModel
from PIL import Image
from transformers import AutoModelForCausalLM, AutoTokenizer

from data import sampled_frame_features
from train import EvidencePrefix, collate, forward


class CheckpointSelector:
    def __init__(self, base, full_checkpoint, video_checkpoint):
        self.lock = Lock()
        self.device = "mps" if torch.backends.mps.is_available() else "cpu"
        self.tokenizer = AutoTokenizer.from_pretrained(base, local_files_only=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(base, local_files_only=True).to(self.device)
        self.model = PeftModel.from_pretrained(
            model, full_checkpoint / "lora", adapter_name="full", local_files_only=True
        ).eval()
        self.model.load_adapter(video_checkpoint / "lora", "video", local_files_only=True)
        self.prefixes = {}
        for key, checkpoint in (("full", full_checkpoint), ("video", video_checkpoint)):
            prefix = EvidencePrefix(model.config.hidden_size).to(self.device)
            prefix.load_state_dict(torch.load(checkpoint / "prefix.pt", map_location="cpu", weights_only=True))
            self.prefixes[key] = prefix.eval()

    def select(self, arm, transcript, images, replies):
        video = None
        if len(images) == 8:
            frames = []
            for data in images:
                with Image.open(BytesIO(data)) as image:
                    resized = image.convert("RGB").resize((32, 32), Image.Resampling.BILINEAR)
                    frames.append(np.asarray(resized, dtype=np.float32) / 255)
            video = sampled_frame_features(np.stack(frames))
        if len(replies) == 1:
            return replies[0]
        adapter = "video" if arm == "ablation_video_only" else "full"
        with self.lock, torch.inference_mode():
            self.model.set_adapter(adapter)
            losses = []
            for reply in replies:
                row = {"text": transcript, "reply": reply, "video": video, "context": ""}
                batch = collate([row], self.tokenizer, self.device, "full")
                loss, _ = forward(self.model, self.prefixes[adapter], batch)
                if not torch.isfinite(loss):
                    raise RuntimeError("The checkpoint could not score the reply.")
                losses.append(loss.item())
        return replies[min(range(len(replies)), key=losses.__getitem__)]
