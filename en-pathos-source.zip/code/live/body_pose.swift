import Foundation
import Vision

// Read one JPEG path per frame. Output normalized movement or abstain.
let names: [VNHumanBodyPoseObservation.JointName] = [.nose, .neck, .leftShoulder, .rightShoulder]
var poses: [[CGPoint]] = []
var wrists: [[String: CGPoint]] = []
for path in CommandLine.arguments.dropFirst() {
    let request = VNDetectHumanBodyPoseRequest()
    let handler = VNImageRequestHandler(url: URL(fileURLWithPath: path), options: [:])
    guard (try? handler.perform([request])) != nil,
          let observations = request.results, observations.count == 1,
          let joints = try? observations[0].recognizedPoints(.all) else {
        print("unknown")
        exit(0)
    }
    let points = names.compactMap { joints[$0] }.filter { $0.confidence >= 0.45 }
    guard points.count == names.count else {
        print("unknown")
        exit(0)
    }
    let left = points[2].location, right = points[3].location
    let width = hypot(left.x - right.x, left.y - right.y)
    guard width > 0.08 else { print("unknown"); exit(0) }
    let center = CGPoint(x: (left.x + right.x) / 2, y: (left.y + right.y) / 2)
    func normalized(_ point: CGPoint) -> CGPoint {
        CGPoint(x: (point.x - center.x) / width, y: (point.y - center.y) / width)
    }
    poses.append(points.prefix(2).map { normalized($0.location) })
    var hands: [String: CGPoint] = [:]
    for wrist in [VNHumanBodyPoseObservation.JointName.leftWrist, .rightWrist] {
        if let point = joints[wrist], point.confidence >= 0.55 {
            hands[wrist.rawValue.rawValue] = normalized(point.location)
        }
    }
    wrists.append(hands)
}
guard poses.count >= 4 else { print("unknown"); exit(0) }
let head = poses.map { $0[0].y - $0[1].y }
let headSteps = zip(head, head.dropFirst()).map { $1 - $0 }
let nod = zip(headSteps, headSteps.dropFirst()).contains {
    abs($0) > 0.06 && abs($1) > 0.06 && $0 * $1 < 0
}
let gesture = zip(wrists, wrists.dropFirst()).contains { before, after in
    before.contains { key, point in
        guard let next = after[key] else { return false }
        return hypot(point.x - next.x, point.y - next.y) > 0.28
    }
}
print(nod ? "possible_nod" : gesture ? "hand_movement" : "unknown")
