import * as THREE from "./three.module.min.js";

export function createGallery(view, interact, onInteract) {
  const world = new THREE.Scene();
  world.background = new THREE.Color("#292333");
  world.fog = new THREE.FogExp2("#292333", 0.035);
  const camera = new THREE.PerspectiveCamera(67, 1, .06, 45);
  const renderer = new THREE.WebGLRenderer({antialias: true});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.setAttribute("aria-hidden", "true");
  view.prepend(renderer.domElement);
  const keys = new Set();
  const objective = view.querySelector("#gallery-objective");
  let target, targetName, opened = false, paused = false;
  let heading = 0, pitch = 0, drag, previous = 0;
  const start = new THREE.Vector3(0, 1.62, 5);
  camera.position.copy(start);
  camera.rotation.order = "YXZ";
  const points = {};

  function box(parent, dimensions, position, color) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...dimensions), new THREE.MeshStandardMaterial({color}));
    mesh.position.set(...position);
    parent.add(mesh);
    return mesh;
  }

  box(world, [14,.2,16], [0,-.1,0], "#49332c");
  for (let x = -6.8; x < 7; x += .29) {
    box(world, [.27,.012,15.8], [x,.004,0], Math.round((x + 7) * 4) % 3 ? "#62463a" : "#705041");
  }
  for (const z of [-8,8]) box(world, [14,4,.25], [0,2,z], "#63516b");
  for (const x of [-7,7]) box(world, [.25,4,16], [x,2,0], "#3f5360");
  for (const x of [-6.8,6.8]) box(world, [.1,.13,15.8], [x,.1,0], "#b09278");
  box(world, [13.8,.13,.1], [0,.1,-7.8], "#b09278");

  const ambient = new THREE.HemisphereLight("#d5dcff", "#825340", 1.35);
  world.add(ambient);
  const lamps = [];
  for (const x of [-4,0,4]) {
    box(world, [.11,.1,13], [x,3.68,0], "#242632");
    for (const z of [-5,0,5]) {
      box(world, [.43,.2,.38], [x,3.54,z], "#f3c999");
      const light = new THREE.PointLight("#ffd7ae", 26, 10);
      light.position.set(x,3.35,z);
      world.add(light);
      lamps.push(light);
    }
  }

  function print(parent, x, z, yaw, colors) {
    const frame = new THREE.Group();
    frame.position.set(x,2,z);
    frame.rotation.y = yaw;
    parent.add(frame);
    box(frame, [1.9,1.56,.16], [0,0,0], "#302222");
    box(frame, [1.76,1.42,.04], [0,0,.091], "#ded0ac");
    box(frame, [1.48,1.18,.018], [0,0,.12], colors[0]);
    const sun = new THREE.Mesh(new THREE.CircleGeometry(.28,32), new THREE.MeshStandardMaterial({color: colors[1]}));
    sun.position.set(.25,.18,.134);
    frame.add(sun);
    const ridge = box(frame, [.91,.22,.015], [-.17,-.18,.14], colors[2]);
    ridge.rotation.z = .24;
    box(frame, [.36,.13,.04], [.68,-.96,.07], "#e6d9b9");
    return frame;
  }
  for (const [i,x] of [-4,0,4].entries()) print(world,x,-7.78,0,[
    ["#29474c","#eea351","#81979b"],["#5c385c","#f2c6a3","#b77676"],["#235365","#e9bc65","#547e71"],
  ][i]);
  const crooked = print(world,-6.8,-1,Math.PI/2,["#524460","#f3d081","#937791"]);
  print(world,6.8,0,-Math.PI/2,["#404e6a","#eca782","#7e8a89"]);

  function station(id, x, z, topColor) {
    const group = new THREE.Group();
    group.position.set(x,0,z);
    world.add(group);
    points[id] = group;
    box(group,[.86,.89,.62],[0,.45,0],"#a5927b");
    return box(group,[.56,.15,.42],[0,1,0],topColor);
  }
  const projector = station("projector",0,1,"#333745");
  box(projector,[.17,.12,.04],[0,0,.22],"#8baec6");
  station("bench",-4,-1,"#e5a968");
  station("note",4,3,"#eee0b0");
  station("book",4,-3,"#9f5c60");
  const credit = station("credit",-4,-4,"#d9bea7");
  const crate = station("crate",0,-5,"#9d6241");
  const lastPrint = station("print",-4,3,"#66959b");
  station("door",0,6.8,"#a58b6e");
  box(world,[2.6,3.2,.17],[0,1.6,7.82],"#344a52");

  function character(id, x, z, shirt, skin, hair) {
    const group = new THREE.Group();
    group.position.set(x,0,z);
    world.add(group);
    points[id] = group;
    box(group,[.52,.64,.29],[0,1.12,0],shirt);
    for (const side of [-1,1]) {
      box(group,[.14,.58,.19],[side*.135,.34,0],"#2b3143");
      const arm = box(group,[.14,.53,.19],[side*.33,1.13,0],shirt);
      arm.rotation.z = side*.12;
      box(group,[.13,.15,.15],[side*.36,.82,0],skin);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(.225,20,14), new THREE.MeshStandardMaterial({color:skin}));
    head.position.y = 1.66;
    group.add(head);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(.235,20,12,0,Math.PI*2,0,1.25), new THREE.MeshStandardMaterial({color:hair}));
    cap.position.y = 1.7;
    group.add(cap);
    for (const side of [-1,1]) box(group,[.034,.038,.014],[side*.073,1.68,.211],"#24202a");
  }
  character("sam",-2,2,"#668c83","#c69271","#392a36");
  character("visitor",2,-2,"#9d607c","#8a563e","#252031");
  character("friend",3,5,"#9b7954","#ddb795","#55443e");

  const beacon = new THREE.Mesh(new THREE.TorusGeometry(.62,.035,10,40), new THREE.MeshBasicMaterial({color:"#ffd080"}));
  beacon.rotation.x = -Math.PI / 2;
  beacon.position.y = .035;
  world.add(beacon);

  function resize() {
    if (!view.clientWidth || !view.clientHeight) return;
    renderer.setSize(view.clientWidth, view.clientHeight, false);
    camera.aspect = view.clientWidth / view.clientHeight;
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(view);
  const distance = () => target ? Math.hypot(camera.position.x - target.position.x, camera.position.z - target.position.z) : Infinity;
  function use() {
    if (!opened && distance() < 1.95) {
      opened = true;
      onInteract();
    }
  }
  interact.onclick = use;
  const bindings = {arrowup:"w", arrowdown:"s", arrowleft:"a", arrowright:"d"};
  view.addEventListener("keydown", event => {
    const key = event.key.toLowerCase();
    const move = bindings[key] || key;
    if ("wasd".includes(move) && move.length === 1) {
      event.preventDefault();
      keys.add(move);
    }
    if (key === "e") use();
  });
  window.addEventListener("keyup", event => keys.delete(bindings[event.key.toLowerCase()] || event.key.toLowerCase()));
  view.addEventListener("focusout", () => keys.clear());
  window.addEventListener("blur", () => keys.clear());
  for (const button of view.querySelectorAll("[data-move]")) {
    button.addEventListener("pointerdown", event => {
      event.preventDefault();
      view.focus({preventScroll:true});
      button.setPointerCapture(event.pointerId);
      keys.add(button.dataset.move);
    });
    button.addEventListener("lostpointercapture", () => keys.delete(button.dataset.move));
    button.addEventListener("click", event => {
      if (!event.detail) walk(button.dataset.move, .45);
    });
  }
  const canvas = renderer.domElement;
  canvas.addEventListener("pointerdown", event => {
    view.focus({preventScroll:true});
    canvas.setPointerCapture(event.pointerId);
    drag = [event.clientX,event.clientY];
  });
  canvas.addEventListener("pointermove", event => {
    if (!drag) return;
    heading -= (event.clientX - drag[0]) * .007;
    pitch = THREE.MathUtils.clamp(pitch - (event.clientY - drag[1]) * .006,-.8,.8);
    drag = [event.clientX,event.clientY];
  });
  canvas.addEventListener("lostpointercapture", () => {drag = undefined;});

  function walk(key, amount) {
    const forward = key === "w" ? 1 : key === "s" ? -1 : 0;
    const side = key === "d" ? 1 : key === "a" ? -1 : 0;
    const x = THREE.MathUtils.clamp(camera.position.x + (-Math.sin(heading)*forward + Math.cos(heading)*side)*amount,-6.35,6.35);
    const z = THREE.MathUtils.clamp(camera.position.z + (-Math.cos(heading)*forward - Math.sin(heading)*side)*amount,-7.32,7.32);
    for (const point of Object.values(points)) {
      if (Math.hypot(x-point.position.x,z-point.position.z) < .58) return;
    }
    camera.position.x = x;
    camera.position.z = z;
  }

  renderer.setAnimationLoop(time => {
    const dt = Math.min((time - previous)/1000,.045);
    previous = time;
    if (paused || !view.clientWidth) return;
    for (const key of keys) walk(key,dt * 3.9 / Math.sqrt(keys.size));
    camera.rotation.set(pitch,heading,0,"YXZ");
    for (const id of ["sam","visitor","friend"]) {
      const person = points[id];
      person.rotation.y = Math.atan2(camera.position.x-person.position.x,camera.position.z-person.position.z);
      person.position.y = Math.sin(time*.003 + person.position.x)*.018;
    }
    const range = distance();
    const near = !opened && range < 1.95;
    interact.hidden = !near;
    const localAngle = target ? Math.atan2(camera.position.x-target.position.x,camera.position.z-target.position.z) - heading : 0;
    const direction = Math.sin(localAngle) > .25 ? " ←" : Math.sin(localAngle) < -.25 ? " →" : Math.cos(localAngle) < 0 ? " ↶" : " ↑";
    const guidance = opened ? targetName : targetName + (near ? "" : direction + " · " + Math.ceil(range) + " m");
    if (objective.textContent !== guidance) objective.textContent = guidance;
    beacon.visible = !opened;
    renderer.render(world,camera);
  });

  return {
    setTarget(id, name, step, effects) {
      paused = false;
      target = points[id];
      targetName = name;
      objective.textContent = name;
      interact.hidden = true;
      interact.textContent = "Interact · " + name;
      opened = false;
      ambient.intensity = step === 0 ? .68 : 1.35;
      lamps.forEach((lamp,index) => { lamp.intensity = step === 0 ? 8 : (effects.lamp && index < 3 ? 36 : 26); });
      crooked.rotation.z = effects.straight ? 0 : -.13;
      credit.material.color.set(effects.credit ? "#e7d18d" : "#d9bea7");
      crate.material.color.set(effects.split ? "#527e77" : "#9d6241");
      lastPrint.visible = !effects.sold;
      points.sam.position.set(effects.samNear ? -1.4 : -2,0,effects.samNear ? -.7 : 2);
      points.visitor.position.z = effects.tour ? -5.4 : -2;
      points.friend.position.x = effects.friend ? 1.7 : 3;
      points.note.position.set(effects.plan ? -3.2 : 4,0,effects.pinned ? -.5 : 3);
      points.visitor.position.x = effects.corner ? -3 : 2;
      points.book.position.z = effects.pinned ? -4 : -3;
      points.crate.position.x = effects.reserved ? -1.4 : 0;
      beacon.position.set(target.position.x,.035,target.position.z);
      resize();
    },
    pause() { paused = true; keys.clear(); },
    reset() { camera.position.copy(start); heading = 0; pitch = 0; keys.clear(); },
  };
}
