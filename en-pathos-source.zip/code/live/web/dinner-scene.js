import * as THREE from "./three.module.min.js";

const material = (color, roughness = .8) => new THREE.MeshStandardMaterial({color, roughness});
const sphere = new THREE.SphereGeometry(1, 24, 16);
const cube = new THREE.BoxGeometry(1, 1, 1);
const cylinder = new THREE.CylinderGeometry(1, 1, 1, 48);

function mesh(parent, geometry, finish, position, scale) {
  const part = new THREE.Mesh(geometry, finish);
  part.position.set(...position);
  part.scale.set(...scale);
  part.castShadow = true;
  part.receiveShadow = true;
  parent.add(part);
  return part;
}

function guest(scene, x, z, turn, skinColor, shirtColor, hairColor, hairstyle) {
  const person = new THREE.Group();
  person.position.set(x, 0, z);
  person.rotation.y = turn;
  scene.add(person);
  const skin = material(skinColor);
  const shirt = material(shirtColor);
  const hair = material(hairColor);
  const trousers = material(0x30313b);
  const chair = material(0x764735);
  const shoes = material(0x46302a);
  mesh(person, cube, chair, [0,.46,-.1], [.56,.09,.56]);
  mesh(person, cube, chair, [0,.84,-.38], [.56,.61,.08]);
  const body = new THREE.Group();
  person.add(body);
  const arms = [];
  const reaching = [];
  const legs = [];
  for (const side of [-1,1]) {
    for (const depth of [-.32,.13]) mesh(person,cube,chair,[side*.22,.22,depth],[.055,.45,.055]);
    const thigh = mesh(body,sphere,trousers,[0,0,0],[1,1,1]);
    const shin = mesh(body,sphere,trousers,[0,0,0],[1,1,1]);
    const shoe = mesh(body,sphere,shoes,[0,0,0],[.071,.041,.106]);
    legs.push({thigh, shin, shoe, side});
  }
  const torso = mesh(body,sphere,shirt,[0,.81,-.055],[.255,.35,.16]);
  mesh(body,cylinder,skin,[0,1.13,-.015],[.078,.13,.074]);
  for (const side of [-1,1]) {
    const arm = new THREE.Group();
    arm.position.set(side*.224,.99,.015);
    arm.rotation.z = side*.24;
    body.add(arm);
    mesh(arm,sphere,shirt,[0,-.12,0],[.077,.15,.075]);
    arm.forearm = mesh(arm,sphere,skin,[0,-.23,.078],[.048,.046,.112]);
    arms.push(arm);
    const reach = new THREE.Group();
    body.add(reach);
    const plateHand = new THREE.Group();
    reach.add(plateHand);
    mesh(plateHand,sphere,skin,[0,0,0],[.029,.014,.036]);
    for (let finger=0;finger<4;finger++) {
      mesh(plateHand,sphere,skin,[-side*(.023+.003*(finger%2)),.004,(finger-1.5)*.014],
        [.023,.007,.0065]);
    }
    const thumb = mesh(plateHand,sphere,skin,[-side*.010,.017,.027],[.011,.017,.008]);
    thumb.rotation.z = side*.34;
    reaching.push({
      group:reach,
      upper:mesh(reach,sphere,shirt,[0,0,0],[1,1,1]),
      lower:mesh(reach,sphere,skin,[0,0,0],[1,1,1]),
      palm:mesh(reach,sphere,skin,[0,0,0],[.052,.037,.043]),
      plateHand,
    });
  }
  const head = new THREE.Group();
  head.position.set(0,1.31,.012);
  body.add(head);
  if (hairstyle === "long") mesh(head,sphere,hair,[0,-.025,-.121],[.169,.221,.102]);
  mesh(head,sphere,skin,[0,0,0],[.152,.185,.139]);
  mesh(head,sphere,hair,[0,.10,-.044],[.156,.114,.132]);
  const tuft = mesh(head,sphere,hair,[-.056,.106,.053],[.113,.058,.092]);
  tuft.rotation.z = -.27;
  if (hairstyle === "bun") mesh(head,sphere,hair,[0,.155,-.126],[.084,.09,.079]);
  const iris = material(hairColor,.45);
  const pupils = material(0x261b19,.35);
  const white = material(0xf6e9da,.35);
  const eyeGroups = [];
  head.scale.set(.94,.96,.94);
  for (const side of [-1,1]) {
    mesh(head,sphere,skin,[side*.145,-.01,-.006],[.03,.049,.026]);
    const eye = new THREE.Group();
    eye.position.set(side*.053,.014,.126);
    head.add(eye);
    mesh(eye,sphere,white,[0,0,0],[.023,.010,.010]);
    mesh(eye,sphere,iris,[0,0,.009],[.009,.009,.004]);
    mesh(eye,sphere,pupils,[0,0,.013],[.004,.004,.002]);
    const brow = mesh(head,sphere,hair,[side*.052,.039,.125],[.023,.004,.007]);
    brow.rotation.z = side*.07;
    eyeGroups.push(eye);
  }
  mesh(head,sphere,skin,[0,-.026,.135],[.028,.035,.031]);
  const mouth = mesh(head,sphere,material(0x783f38),[0,-.075,.126],[.038,.009,.012]);
  return {person, body, arms, reaching, legs, torso, head, mouth, eyeGroups};
}

export function mountDinnerScene(host) {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({antialias:true, alpha:false});
  } catch {
    return;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.3;
  renderer.domElement.setAttribute("aria-hidden", "true");
  host.prepend(renderer.domElement);
  host.classList.add("has-dinner-scene");
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x352827);
  const camera = new THREE.PerspectiveCamera(34, 1, .1, 25);
  const views = {
    arrival: [[1.72,2.37,5.0],[-.32,1.03,-.25]],
    oven: [[-1.88,1.89,3.28],[-.88,1.08,-.59]],
    bread: [[.48,1.83,2.74],[.10,1.16,-.77]],
    water: [[2.92,1.68,2.06],[.98,1.04,-.41]],
    spill: [[.93,2.34,2.64],[.25,.81,.28]],
    meeting: [[2.67,1.51,1.98],[1.06,1.09,-.47]],
    tray: [[-2.04,1.71,2.42],[-.94,1.06,-.13]],
    music: [[2.15,2.36,4.85],[0,.99,-.21]],
    week: [[2.27,2.34,4.73],[.19,1.01,-.20]],
    joke: [[2.97,1.48,1.57],[1.10,1.09,-.48]],
    cake: [[1.44,2.36,2.82],[.07,.88,-.07]],
    clearing: [[-2.27,1.81,2.55],[-.95,1.03,-.18]],
    memory: [[.59,1.51,2.62],[-.10,1.16,-.86]],
    numbers: [[-2.03,1.66,2.49],[-1.02,1.04,-.19]],
    goodbye: [[1.64,2.40,5.11],[-.23,1.01,-.35]],
  };
  const wideShots = new Set(["arrival","music","week","goodbye"]);
  const aimedAt = new THREE.Vector3();
  const fromPosition = new THREE.Vector3();
  const fromTarget = new THREE.Vector3();
  const toPosition = new THREE.Vector3();
  const toTarget = new THREE.Vector3();
  camera.position.fromArray(views.arrival[0]);
  aimedAt.fromArray(views.arrival[1]);
  camera.lookAt(aimedAt);
  let cameraMoveStarted = 0;
  let activeView;
  let wasFirstPerson = false;
  const eyeDirection = new THREE.Vector3();
  let arrivalLookTime;
  let arrivalYaw = 0;
  const tableFocus = {
    water: [.70,.99,-.10],
    spill: [.42,.80,.39],
    tray: [-.53,.96,.11],
    cake: [.10,.91,.04],
    clearing: [-.47,.94,.16],
  };

  function updateView(moment,time,walking,snap) {
    const focus = tableFocus[moment];
    const firstPerson = walking || Boolean(focus);
    const shot = firstPerson ? "first-person" : "third-person";
    if (host.dataset.pointOfView !== shot) host.dataset.pointOfView = shot;
    const {head,body} = guests.You;
    head.visible = !firstPerson;
    const fov = firstPerson ? (camera.aspect<1.55 ? 69 : 55) : (camera.aspect<1.55 ? 43 : 34);
    const near = firstPerson ? .035 : .1;
    if (camera.fov !== fov || camera.near !== near) {
      camera.fov = fov;
      camera.near = near;
      camera.updateProjectionMatrix();
    }
    const entering = moment === "arrival" && walking;
    if (!entering) arrivalLookTime = undefined;
    if (firstPerson) {
      head.localToWorld(camera.position.set(0,.027,entering ? 0 : .128));
      if (walking) {
        body.getWorldDirection(eyeDirection);
        if (entering) {
          // Let the gaze follow the turn without inheriting every change in body heading.
          const heading = Math.atan2(eyeDirection.x,eyeDirection.z);
          if (arrivalLookTime === undefined) {
            arrivalYaw = heading;
          } else {
            const elapsed = THREE.MathUtils.clamp((time-arrivalLookTime)/1000,0,.05);
            const difference = Math.atan2(Math.sin(heading-arrivalYaw),Math.cos(heading-arrivalYaw));
            const limit = 1.35*elapsed;
            arrivalYaw += THREE.MathUtils.clamp(
              difference*(1-Math.exp(-elapsed/.34)),-limit,limit);
          }
          arrivalLookTime = time;
          eyeDirection.set(Math.sin(arrivalYaw),0,Math.cos(arrivalYaw));
          camera.position.addScaledVector(eyeDirection,.128);
        }
        aimedAt.copy(camera.position).addScaledVector(eyeDirection,2.2);
        aimedAt.y -= .16;
      } else {
        aimedAt.fromArray(focus);
      }
      camera.lookAt(aimedAt);
      activeView = null;
    } else {
      moveCamera(moment,time,snap || wasFirstPerson);
    }
    wasFirstPerson = firstPerson;
  }

  function moveCamera(moment,time,snap) {
    const [position,target] = views[moment] || views.arrival;
    if (moment !== activeView) {
      activeView = moment;
      fromPosition.copy(camera.position);
      fromTarget.copy(aimedAt);
      toPosition.fromArray(position);
      toTarget.fromArray(target);
      cameraMoveStarted = snap ? time-940 : time;
    }
    const elapsed = Math.max(0,time-cameraMoveStarted);
    const blend = snap ? 1 : ease(elapsed/940);
    camera.position.copy(fromPosition).lerp(toPosition,blend);
    aimedAt.copy(fromTarget).lerp(toTarget,blend);
    if (!snap && !wideShots.has(moment)) {
      camera.position.lerp(aimedAt,.033*ease((elapsed-940)/5200));
    }
    camera.lookAt(aimedAt);
  }

  scene.add(new THREE.HemisphereLight(0xffedd9,0x666571,1.55));
  const warm = new THREE.DirectionalLight(0xffcd9e,2.0);
  warm.position.set(-2,4,2);
  warm.castShadow = true;
  warm.shadow.mapSize.set(1024,1024);
  warm.shadow.bias = -.00035;
  scene.add(warm);
  const windowLight = new THREE.DirectionalLight(0xabc4ef,.85);
  windowLight.position.set(3,2,-2);
  scene.add(windowLight);
  const lampLight = new THREE.PointLight(0xffbc76,9,4);
  lampLight.position.set(0,2.06,0);
  scene.add(lampLight);

  mesh(scene,cube,material(0x6e4c3f),[0,-.075,0],[12,.15,12]);
  const wall = material(0x6f5146);
  const trim = material(0x492e28);
  const frame = material(0xb68857);
  const doorway = {left:-2.45, right:-1.85, height:1.86, depth:-2.39};
  for (const [left,right] of [[-5,doorway.left],[doorway.right,5.60]]) {
    const middle = (left+right)/2;
    mesh(scene,cube,wall,[middle,1.6,-2.45],[right-left,3.2,.12]);
    for (const y of [.12,.76]) mesh(scene,cube,trim,[middle,y,-2.37],[right-left,.055,.06]);
  }
  const doorCenter = (doorway.left+doorway.right)/2;
  mesh(scene,cube,wall,[doorCenter,2.53,-2.45],[.60,1.34,.12]);
  for (const edge of [doorway.left,doorway.right]) {
    mesh(scene,cube,frame,[edge,.94,doorway.depth],[.067,1.88,.17]);
  }
  mesh(scene,cube,frame,[doorCenter,doorway.height,doorway.depth],[.67,.078,.17]);
  mesh(scene,cube,frame,[doorCenter,.008,doorway.depth],[.58,.016,.16]);

  const hall = material(0x69746a);
  const hallwayRunner = material(0x824f42);
  mesh(scene,cube,hall,[doorCenter,1.32,-4.16],[2.51,2.64,.10]);
  mesh(scene,cube,hall,[-3.17,1.32,-3.31],[.10,2.64,1.66]);
  mesh(scene,cube,hall,[-1.22,1.32,-3.31],[.10,2.64,1.66]);
  mesh(scene,cube,hallwayRunner,[doorCenter,.008,-3.25],[.43,.016,1.40]);
  mesh(scene,cube,frame,[doorCenter,1.18,-4.07],[.44,.59,.07]);
  mesh(scene,cube,material(0xd4bd91),[doorCenter,1.18,-4.025],[.33,.48,.024]);
  const hallLight = new THREE.PointLight(0xffca8b,8,3.2);
  hallLight.position.set(doorCenter,1.74,-3.43);
  scene.add(hallLight);
  mesh(scene,sphere,new THREE.MeshBasicMaterial({color:0xffd7a1}),
    [doorCenter,1.83,-3.43],[.10,.075,.10]);
  mesh(scene,cube,frame,[.94,1.73,-2.37],[.83,.98,.075]);
  const rainCanvas = document.createElement("canvas");
  rainCanvas.width = 160;
  rainCanvas.height = 190;
  const rainInk = rainCanvas.getContext("2d");
  const rainSky = rainInk.createLinearGradient(0,0,0,190);
  rainSky.addColorStop(0,"#263b59");
  rainSky.addColorStop(1,"#617b89");
  const rainTexture = new THREE.CanvasTexture(rainCanvas);
  rainTexture.colorSpace = THREE.SRGBColorSpace;
  const viewOutside = new THREE.Mesh(new THREE.PlaneGeometry(.73,.88),
    new THREE.MeshBasicMaterial({map:rainTexture,toneMapped:false}));
  viewOutside.position.set(.94,1.73,-2.306);
  scene.add(viewOutside);
  let lastRainFrame = -Infinity;
  function drawRain(time) {
    if (time-lastRainFrame<45) return;
    lastRainFrame = time;
    rainInk.fillStyle = rainSky;
    rainInk.fillRect(0,0,160,190);
    rainInk.fillStyle = "#263b44";
    rainInk.beginPath();
    rainInk.moveTo(0,158);
    for (let x=0;x<=160;x+=8) rainInk.lineTo(x,140+Math.sin(x*.077)*7+Math.cos(x*.235)*4);
    rainInk.lineTo(160,190);
    rainInk.lineTo(0,190);
    rainInk.fill();
    rainInk.strokeStyle = "#bad5ea86";
    rainInk.lineWidth = 1.15;
    rainInk.beginPath();
    for (let i=0;i<37;i++) {
      const x = (i*47.3)%166;
      const y = (i*63.4+time*(.105+i%4*.025))%211-13;
      rainInk.moveTo(x,y);
      rainInk.lineTo(x-3.8,y+11+i%4*2);
    }
    rainInk.stroke();
    rainTexture.needsUpdate = true;
  }
  mesh(scene,cube,frame,[.94,1.73,-2.29],[.032,.88,.026]);
  mesh(scene,cube,frame,[.94,1.73,-2.29],[.73,.033,.026]);
  const curtainRod = mesh(scene,cylinder,material(0xa98356),[.94,2.298,-2.19],[.018,1.13,.018]);
  curtainRod.rotation.z = Math.PI/2;
  const curtainCloth = new THREE.MeshStandardMaterial({color:0xc3a27f,roughness:1,side:THREE.DoubleSide});
  for (const x of [.48,1.40]) {
    const fabric = new THREE.PlaneGeometry(.23,1.065,24,15);
    const points = fabric.attributes.position;
    for (let index=0;index<points.count;index++) {
      const horizontal = points.getX(index);
      const vertical = points.getY(index);
      const hem = Math.PI*(horizontal/.23+.5);
      points.setX(index,horizontal*(1.1-.23*Math.cos(vertical*4)));
      points.setY(index,vertical+(.5-vertical)*.022*Math.cos(hem*6));
      points.setZ(index,.029*Math.cos(hem*6));
    }
    fabric.computeVertexNormals();
    const curtain = new THREE.Mesh(fabric,curtainCloth);
    curtain.position.set(x,1.747,-2.172);
    curtain.castShadow = true;
    curtain.receiveShadow = true;
    scene.add(curtain);
  }


  const walnut = material(0x814628,.55);
  mesh(scene,cylinder,walnut,[0,.73,0],[1.17,.12,.82]);
  mesh(scene,cylinder,walnut,[0,.37,0],[.14,.71,.14]);
  mesh(scene,cylinder,walnut,[0,.055,0],[.49,.075,.38]);
  mesh(scene,cube,material(0x794843),[0,.794,0],[.42,.012,1.49]);
  const brass = material(0xc49b52,.3);
  const linen = material(0xe2c7a6);
  const greenery = material(0x456a4d);
  const petals = [material(0xd97b68),material(0xeec27c),material(0xe3a4a1)];
  mesh(scene,cube,frame,[-1.15,1.88,-2.36],[.52,.40,.055]);
  mesh(scene,cube,material(0xebc7a0),[-1.15,1.88,-2.325],[.45,.33,.02]);
  mesh(scene,sphere,greenery,[-1.15,1.85,-2.305],[.15,.075,.014]);
  mesh(scene,sphere,petals[0],[-1.09,1.92,-2.30],[.049,.054,.018]);

  // The sideboard sits against the wall, outside the aisle used during arrivals.
  const cabinet = material(0x584234,.61);
  const cabinetFront = material(0x8e6246,.56);
  const pottery = material(0xddcdb1,.49);
  mesh(scene,cube,cabinet,[2.02,.42,-2.17],[1.23,.84,.39]);
  mesh(scene,cube,walnut,[2.02,.86,-2.16],[1.29,.06,.43]);
  for (const x of [1.72,2.32]) {
    mesh(scene,cube,cabinetFront,[x,.45,-1.967],[.53,.61,.033]);
    mesh(scene,sphere,brass,[x+(x<2 ? .17 : -.17),.57,-1.936],[.021,.021,.018]);
  }
  for (let index=0;index<5;index++) {
    mesh(scene,cylinder,pottery,[1.54,.900+index*.017,-2.15],[.142,.017,.142]);
  }
  const playerX = 2.00;
  const playerZ = -2.15;
  const recordBase = material(0x493630,.55);
  const recordFinish = material(0x221e24,.30);
  mesh(scene,cube,recordBase,[playerX,.923,playerZ],[.43,.064,.33]);
  const record = new THREE.Group();
  record.position.set(playerX-.027,.965,playerZ);
  scene.add(record);
  mesh(record,cylinder,recordFinish,[0,0,0],[.132,.014,.132]);
  mesh(record,cylinder,petals[1],[0,.009,0],[.043,.005,.043]);
  mesh(record,cube,pottery,[-.018,.013,0],[.032,.004,.011]);
  mesh(scene,cylinder,brass,[playerX+.157,.973,playerZ-.081],[.023,.027,.023]);
  const tonearm = mesh(scene,cube,brass,[playerX+.098,.988,playerZ-.040],[.156,.013,.016]);
  tonearm.rotation.y = .59;
  const noteCanvas = document.createElement("canvas");
  noteCanvas.width = noteCanvas.height = 96;
  const noteInk = noteCanvas.getContext("2d");
  noteInk.font = "bold 70px Georgia, serif";
  noteInk.textAlign = "center";
  noteInk.textBaseline = "middle";
  noteInk.fillStyle = "#ffe6af";
  noteInk.fillText("♫",48,51);
  const noteTexture = new THREE.CanvasTexture(noteCanvas);
  noteTexture.colorSpace = THREE.SRGBColorSpace;
  const musicNotes = Array.from({length:3},() => {
    const note = new THREE.Sprite(new THREE.SpriteMaterial({map:noteTexture,transparent:true,depthWrite:false}));
    scene.add(note);
    return note;
  });
  mesh(scene,cylinder,material(0x94624e),[2.36,.984,-2.16],[.095,.187,.095]);
  for (let index=0;index<5;index++) {
    const leaf = mesh(scene,sphere,greenery,[2.36+(index-2)*.040,1.13+index%2*.05,-2.15],
      [.036,.09,.031]);
    leaf.rotation.z = (index-2)*-.37;
  }
  mesh(scene,cube,cabinet,[2.19,1.45,-2.28],[.87,.044,.22]);
  for (const [index,x] of [1.94,2.16,2.37].entries()) {
    mesh(scene,cylinder,petals[index],[x,1.526,-2.27],[.055,.11,.055]);
    const handle = mesh(scene,new THREE.TorusGeometry(.035,.008,8,20),petals[index],[x+.057,1.529,-2.26],[1,1,1]);
    handle.rotation.y = .28;
  }
  mesh(scene,cube,frame,[2.28,1.99,-2.365],[.58,.53,.07]);
  mesh(scene,cube,linen,[2.28,1.99,-2.323],[.50,.45,.026]);
  mesh(scene,sphere,petals[1],[2.37,2.064,-2.304],[.068,.068,.01]);
  mesh(scene,sphere,greenery,[2.24,1.892,-2.301],[.16,.095,.012]);
  mesh(scene,cube,wall,[-3.35,1.6,-.2],[.12,3.2,4.35]);
  mesh(scene,cube,trim,[-3.278,.129,-.2],[.043,.07,4.35]);
  const consoleZ = 1.06;
  const consoleX = -3.04;
  mesh(scene,cube,cabinet,[consoleX,.71,consoleZ],[.34,.10,1.18]);
  mesh(scene,cube,walnut,[consoleX,.785,consoleZ],[.39,.05,1.23]);
  for (const x of [-3.16,-2.91]) {
    for (const z of [.54,1.58]) mesh(scene,cube,cabinet,[x,.35,z],[.057,.70,.057]);
  }
  mesh(scene,cube,walnut,[consoleX,.25,consoleZ],[.31,.035,1.08]);
  for (const [index,z] of [.73,.82,.90,1.00].entries()) {
    const book = mesh(scene,cube,petals[index%3],[-3.05,.365,z],[.20,.196+index*.02,.06]);
    book.rotation.x = (index-1)*.045;
    mesh(scene,cube,linen,[-2.946,.364,z],[.008,.17+index*.02,.041]);
  }
  mesh(scene,cylinder,pottery,[consoleX,.88,1.40],[.094,.14,.094]);
  for (const [index,z] of [1.33,1.37,1.42,1.47].entries()) {
    const leaf = mesh(scene,sphere,greenery,[consoleX+.02,index%2*.036+1.035,z],[.052,.106,.037]);
    leaf.rotation.x = (index-1.5)*.37;
  }
  mesh(scene,cylinder,brass,[consoleX,.824,.64],[.097,.025,.097]);
  mesh(scene,cylinder,brass,[consoleX,.96,.64],[.014,.25,.014]);
  mesh(scene,new THREE.CylinderGeometry(.071,.132,.17,28),linen,[consoleX,1.105,.64],[1,1,1]);
  mesh(scene,cylinder,new THREE.MeshBasicMaterial({color:0xffd7a6}),
    [consoleX,1.026,.64],[.112,.011,.112]);
  const consoleLight = new THREE.PointLight(0xffbc80,2.8,1.65);
  consoleLight.position.set(consoleX+.08,1.035,.64);
  scene.add(consoleLight);

  // Claude Monet, The Beach at Sainte-Adresse (1867). Art Institute of Chicago, public domain.
  const paintingZ = .74;
  const paintingY = 1.94;
  mesh(scene,cube,frame,[-3.263,paintingY,paintingZ],[.074,1.16,1.57]);
  mesh(scene,cube,trim,[-3.220,paintingY,paintingZ],[.016,1.09,1.49]);
  const paintingTexture = new THREE.TextureLoader().load("./monet-sainte-adresse.jpg", () => draw());
  paintingTexture.colorSpace = THREE.SRGBColorSpace;
  paintingTexture.anisotropy = Math.min(8,renderer.capabilities.getMaxAnisotropy());
  const painting = new THREE.Mesh(new THREE.PlaneGeometry(1.43,1.044),
    new THREE.MeshStandardMaterial({map:paintingTexture,roughness:.92}));
  painting.position.set(-3.209,paintingY,paintingZ);
  painting.rotation.y = Math.PI/2;
  scene.add(painting);

  // Keep the right-hand aisle open between the dining table and the furniture.
  mesh(scene,cube,wall,[5.55,1.60,.57],[.11,3.20,6.06]);
  mesh(scene,cube,trim,[5.477,.13,.57],[.045,.070,6.06]);

  const bookcase = new THREE.Group();
  bookcase.position.set(5.24,0,1.44);
  bookcase.rotation.y = -Math.PI/2;
  scene.add(bookcase);
  for (const x of [-.55,.55]) {
    mesh(bookcase,cube,cabinet,[x,.52,0],[.056,1.04,.37]);
  }
  mesh(bookcase,cube,cabinet,[0,.52,-.172],[1.1,1.04,.035]);
  for (const y of [.12,.49,.98]) {
    mesh(bookcase,cube,walnut,[0,y,0],[1.16,.048,.40]);
  }
  const bookCovers = [greenery,petals[1],petals[0],material(0x566e86)];
  for (const [row,count] of [[.143,5],[.514,7]]) {
    for (let index=0;index<count;index++) {
      const h = .16 + index%3*.043;
      mesh(bookcase,cube,bookCovers[index%4],[-.46+.093*index,row+h/2,.033],[.075,h,.22]);
    }
  }
  mesh(bookcase,sphere,pottery,[.30,1.073,.055],[.088,.068,.087]);
  mesh(bookcase,cylinder,brass,[-.27,1.016,.030],[.076,.023,.076]);
  mesh(bookcase,cylinder,brass,[-.27,1.135,.030],[.012,.230,.012]);
  mesh(bookcase,new THREE.CylinderGeometry(.061,.12,.137,24),linen,[-.27,1.28,.030],[1,1,1]);
  mesh(bookcase,cylinder,new THREE.MeshBasicMaterial({color:0xffd7a6}),[-.27,1.217,.030],[.098,.011,.098]);
  const readingLight = new THREE.PointLight(0xffbc80,3.1,1.85);
  readingLight.position.set(5.10,1.225,1.22);
  scene.add(readingLight);

  const armchair = new THREE.Group();
  armchair.position.set(4.45,0,2.27);
  armchair.rotation.y = -1.18;
  scene.add(armchair);
  const upholstery = material(0x587370);
  for (const x of [-.225,.225]) {
    for (const z of [-.22,.22]) mesh(armchair,cube,cabinet,[x,.12,z],[.054,.24,.054]);
  }
  mesh(armchair,cube,upholstery,[0,.31,0],[.57,.22,.58]);
  mesh(armchair,sphere,upholstery,[0,.432,.01],[.273,.074,.258]);
  mesh(armchair,sphere,upholstery,[0,.64,-.215],[.284,.286,.093]);
  for (const x of [-.278,.278]) {
    mesh(armchair,sphere,upholstery,[x,.51,.015],[.073,.106,.24]);
  }
  const cushion = mesh(armchair,sphere,petals[1],[.045,.603,-.123],[.159,.165,.059]);
  cushion.rotation.z = -.16;

  mesh(scene,cube,frame,[5.472,1.87,1.49],[.055,.55,.72]);
  mesh(scene,cube,linen,[5.436,1.87,1.49],[.018,.49,.66]);
  mesh(scene,sphere,petals[1],[5.423,1.962,1.59],[.009,.065,.065]);
  mesh(scene,sphere,greenery,[5.418,1.792,1.45],[.011,.103,.215]);

  // The walking camera looks toward this end of the room on the way to the table.
  const loungeWallZ = 5.64;
  mesh(scene,cube,wall,[1.10,1.60,loungeWallZ],[8.9,3.20,.12]);
  mesh(scene,cube,wall,[-3.35,1.60,3.81],[.12,3.20,3.70]);
  mesh(scene,cube,wall,[5.55,1.60,4.62],[.11,3.20,2.04]);
  mesh(scene,cube,trim,[-3.271,.13,3.81],[.043,.07,3.70]);
  mesh(scene,cube,trim,[5.477,.13,4.62],[.045,.07,2.04]);
  mesh(scene,cube,trim,[1.10,.13,loungeWallZ-.08],[8.9,.07,.045]);

  const lounge = new THREE.Group();
  lounge.position.set(-1.54,0,4.76);
  scene.add(lounge);
  const sofaFabric = material(0x596d61);
  const sofaSeat = material(0x708274);
  const throwFabric = material(0x996759);
  for (const x of [-.86,.86]) {
    for (const z of [-.27,.27]) mesh(lounge,cube,walnut,[x,.105,z],[.08,.21,.08]);
    mesh(lounge,cube,sofaFabric,[x*1.12,.43,0],[.19,.42,.76]);
  }
  mesh(lounge,cube,sofaFabric,[0,.29,.02],[1.95,.29,.73]);
  mesh(lounge,cube,sofaFabric,[0,.62,.30],[1.96,.57,.19]);
  for (const x of [-.435,.435]) {
    mesh(lounge,cube,sofaSeat,[x,.457,-.028],[.83,.13,.59]);
    mesh(lounge,sphere,sofaSeat,[x,.655,.205],[.405,.235,.11]);
  }
  const throwPillow = mesh(lounge,sphere,throwFabric,[-.62,.615,.065],[.19,.17,.083]);
  throwPillow.rotation.z = .24;
  const sofaPillow = mesh(lounge,sphere,linen,[.65,.604,.056],[.16,.145,.077]);
  sofaPillow.rotation.z = -.33;

  const loungeRug = material(0x886259);
  mesh(scene,cylinder,loungeRug,[-1.44,.007,4.01],[1.32,.013,.83]);
  const loungeBorder = mesh(scene,new THREE.RingGeometry(.91,.931,64),frame,
    [-1.44,.014,4.01],[1.32,.83,1]);
  loungeBorder.rotation.x = -Math.PI/2;

  const loungeLampX = -.16;
  const loungeLampZ = 4.87;
  mesh(scene,cylinder,brass,[loungeLampX,.044,loungeLampZ],[.18,.087,.18]);
  mesh(scene,cylinder,brass,[loungeLampX,.84,loungeLampZ],[.021,1.59,.021]);
  mesh(scene,new THREE.CylinderGeometry(.14,.26,.30,32),linen,
    [loungeLampX,1.64,loungeLampZ],[1,1,1]);
  mesh(scene,cylinder,new THREE.MeshBasicMaterial({color:0xffd7a6}),
    [loungeLampX,1.496,loungeLampZ],[.235,.012,.235]);
  const loungeLight = new THREE.PointLight(0xffc391,5.2,3.1);
  loungeLight.position.set(loungeLampX,1.47,loungeLampZ-.09);
  scene.add(loungeLight);

  for (const [i,x] of [-2.29,-1.53,-.77].entries()) {
    const y = i === 1 ? 1.91 : 1.82;
    mesh(scene,cube,frame,[x,y,5.55],[.57,.66,.065]);
    mesh(scene,cube,linen,[x,y,5.508],[.49,.58,.02]);
    for (const side of [-1,1]) {
      const leaf = mesh(scene,sphere,i===1 ? sofaSeat : greenery,
        [x+side*.089,y+.055*side,5.486],[.078,.174,.012]);
      leaf.rotation.z = side*.61;
    }
  }

  // Dress the long wall visible when the player turns toward the dining table.
  const plantX = 4.82;
  const plantZ = 3.49;
  mesh(scene,new THREE.CylinderGeometry(.19,.14,.36,28),throwFabric,
    [plantX,.18,plantZ],[1,1,1]);
  mesh(scene,cylinder,trim,[plantX,.356,plantZ],[.167,.014,.167]);
  for (const [i, angle] of [0,1.1,2.2,3.3,4.4,5.5].entries()) {
    const leaf = mesh(scene,sphere,i%2 ? greenery : sofaSeat,
      [plantX+.17*Math.cos(angle),.61+.078*(i%3),plantZ+.17*Math.sin(angle)],
      [.079,.29,.051]);
    leaf.rotation.set(.47*Math.sin(angle),0,-.47*Math.cos(angle));
  }
  for (const [i,z] of [-.38,.29].entries()) {
    const y = i ? 1.75 : 1.96;
    mesh(scene,cube,frame,[5.468,y,z],[.054,.58,.48]);
    mesh(scene,cube,linen,[5.434,y,z],[.019,.50,.40]);
    mesh(scene,sphere,i ? throwFabric : sofaFabric,[5.419,y-.025,z],[.01,.118,.128]);
    mesh(scene,sphere,petals[1],[5.418,y+.091,z+.075],[.01,.051,.052]);
  }

  const rug = material(0x744b4b);
  mesh(scene,cylinder,rug,[.02,.003,.10],[1.83,.006,1.35]);
  const rugEdge = mesh(scene,new THREE.RingGeometry(.94,.957,96),material(0xb6856d),
    [.02,.0062,.10],[1.83,1.35,1]);
  rugEdge.rotation.x = -Math.PI/2;

  const vase = material(0x53746d,.28);
  mesh(scene,sphere,vase,[-.29,.871,-.22],[.071,.081,.071]);
  for (const [index,dx] of [-.047,0,.047].entries()) {
    const stem = mesh(scene,cylinder,greenery,[-.29+dx,.993,-.22],[.008,.15,.008]);
    stem.rotation.z = -dx*5;
    mesh(scene,sphere,petals[index],[-.29+dx*1.4,1.075+index*.025,-.22],[.033,.028,.034]);
  }
  const flames = [];
  const wax = material(0xf7ddac);
  const fire = new THREE.MeshBasicMaterial({color:0xffc465});
  for (const [x,z] of [[.28,-.18],[-.20,.26]]) {
    mesh(scene,cylinder,brass,[x,.81,z],[.059,.025,.059]);
    mesh(scene,cylinder,wax,[x,.884,z],[.021,.14,.021]);
    const flame = mesh(scene,sphere,fire,[x,.972,z],[.012,.023,.012]);
    flame.castShadow = false;
    const light = new THREE.PointLight(0xff9f4f,.22,.72);
    light.position.set(x,.981,z);
    scene.add(light);
    flames.push({flame,light});
  }

  const china = material(0xffebce,.36);
  const steel = material(0xa7a9a8,.26);
  const tea = material(0xd99b60,.23);
  const placeGlasses = [];
  const platedStarter = new THREE.Group();
  const platedMain = new THREE.Group();
  const platedDessert = new THREE.Group();
  scene.add(platedStarter,platedMain,platedDessert);
  const potatoes = material(0xd4a659);
  const carrots = material(0xc86f3e);
  const cakeFilling = material(0xb77958);
  const icing = material(0xf0d6aa);
  for (const [x,z] of [[-.63,-.45],[.77,-.05],[0,-.57],[.03,.56]]) {
    mesh(scene,cylinder,china,[x,.811,z],[.151,.029,.151]);
    mesh(scene,cylinder,material(0xfaf1e4),[x,.826,z],[.103,.009,.103]);
    mesh(scene,cube,steel,[x+.18,.809,z],[.018,.013,.20]);
    mesh(scene,cube,linen,[x-.19,.804,z+.01],[.055,.014,.17]);
    mesh(scene,cube,steel,[x-.19,.820,z+.03],[.015,.012,.12]);
    for (const tine of [-.012,0,.012]) mesh(scene,cube,steel,[x-.19+tine,.821,z-.048],[.005,.01,.041]);
    placeGlasses.push(mesh(scene,cylinder,tea,[x-.13,.860,z-.15],[.042,.136,.042]));
    const toast = mesh(platedStarter,cube,potatoes,[x-.022,.846,z],[.087,.028,.058]);
    toast.rotation.y = -.32;
    for (const [dx,dz] of [[-.044,-.012],[-.017,.014],[.007,-.006],[.046,.028]]) {
      mesh(platedStarter,sphere,carrots,[x+dx,.865,z+dz],[.015,.009,.013]);
    }
    mesh(platedStarter,sphere,greenery,[x+.053,.841,z-.035],[.024,.011,.016]);
    for (const [dx,dz] of [[-.034,-.026],[.014,-.030],[-.025,.024]]) {
      mesh(platedMain,sphere,potatoes,[x+dx,.852,z+dz],[.024,.023,.021]);
    }
    for (const [dx,dz] of [[.046,.016],[.025,.048]]) {
      const carrot = mesh(platedMain,cube,carrots,[x+dx,.842,z+dz],[.037,.024,.018]);
      carrot.rotation.y = .6;
    }
    mesh(platedMain,sphere,greenery,[x-.049,.844,z+.048],[.026,.016,.015]);
    const wedge = new THREE.CylinderGeometry(.058,.058,.038,3);
    mesh(platedDessert,wedge,cakeFilling,[x,.850,z],[1,1,1]);
    mesh(platedDessert,wedge,icing,[x,.873,z],[1,.22,1]);
  }
  const platter = mesh(scene,cylinder,china,[0,.819,.03],[.19,.036,.19]);
  const food = new THREE.Group();
  food.position.copy(platter.position);
  scene.add(food);
  for (let i=0;i<7;i++) {
    const angle = i*2.4;
    mesh(food,sphere,material(i%2 ? 0xb96437 : 0xba9447),
      [Math.cos(angle)*.105,.027,Math.sin(angle)*.105],[.048,.035,.043]);
  }
  const bulb = new THREE.MeshBasicMaterial({color:0xffd49b});
  mesh(scene,cylinder,trim,[0,2.58,0],[.014,.72,.014]);
  mesh(scene,new THREE.CylinderGeometry(.12,.29,.25,48),material(0x8d5939),[0,2.17,0],[1,1,1]);
  mesh(scene,cylinder,bulb,[0,2.048,0],[.24,.016,.24]);

  const guests = {
    Sam: guest(scene,-1.31,-.35,1.08,0xc98761,0x476853,0x402a20,"short"),
    Maya: guest(scene,-.15,-1.03,.12,0x8f543e,0xab5f4e,0x261c22,"long"),
    Leo: guest(scene,1.21,-.62,-.91,0xd9a17a,0x4c657e,0x392920,"bun"),
    You: guest(scene,-.59,.96,2.65,0xbe835e,0xc69638,0x352621,"short"),
  };
  const cat = new THREE.Group();
  const ginger = material(0xac7248);
  const muzzle = material(0xe9cfac);
  const darkCat = material(0x473025);
  const nose = material(0x704840);
  const amber = material(0xb8a35d,.36);
  const earPink = material(0xc18477);
  const tabbyBase = new THREE.Color(0xbd8557);
  const tabbyStripe = new THREE.Color(0x684332);
  const furColor = new THREE.Color();
  const tabby = new THREE.MeshStandardMaterial({vertexColors:true,roughness:.94});
  function colorFur(geometry, sample) {
    const points = geometry.attributes.position;
    const colors = [];
    for (let index=0;index<points.count;index++) {
      furColor.copy(tabbyBase).lerp(tabbyStripe,sample(index,points));
      colors.push(furColor.r,furColor.g,furColor.b);
    }
    geometry.setAttribute("color",new THREE.Float32BufferAttribute(colors,3));
    return geometry;
  }

  scene.add(cat);
  const catBody = new THREE.Group();
  cat.add(catBody);
  const coat = colorFur(new THREE.SphereGeometry(1,64,40),(index,points) => {
    const back = THREE.MathUtils.smoothstep(points.getY(index),-.45,.35);
    const stripes = Math.cos(27*points.getZ(index)+4.3*points.getY(index)+2*points.getX(index)**2);
    return .70*back*THREE.MathUtils.smoothstep(stripes,.39,.90);
  });
  mesh(catBody,coat,tabby,[0,.194,-.031],[.077,.084,.179]);
  mesh(catBody,sphere,ginger,[0,.19,.101],[.072,.094,.082]);
  mesh(catBody,sphere,ginger,[0,.184,-.137],[.080,.083,.082]);
  mesh(catBody,sphere,muzzle,[0,.146,.128],[.049,.060,.052]);
  const catHead = new THREE.Group();
  catHead.position.set(0,.239,.158);
  catBody.add(catHead);
  mesh(catHead,sphere,ginger,[0,0,0],[.057,.055,.052]);
  const earShape = new THREE.Shape();
  earShape.moveTo(-.027,0);
  earShape.quadraticCurveTo(-.02,.037,-.009,.056);
  earShape.quadraticCurveTo(.013,.047,.027,0);
  earShape.closePath();
  const earShell = new THREE.ExtrudeGeometry(earShape,{depth:.009,bevelEnabled:true,bevelThickness:.003,bevelSize:.003,bevelSegments:2,steps:1});
  const earInner = new THREE.ShapeGeometry(earShape);
  const whiskerInk = new THREE.LineBasicMaterial({color:0xf2d7b1,transparent:true,opacity:.78});
  for (const side of [-1,1]) {
    const ear = mesh(catHead,earShell,ginger,[side*.042,.031,-.014],[1,1,1]);
    ear.rotation.z = -side*.24;
    mesh(ear,earInner,earPink,[0,.006,.012],[.65,.70,1]);
    mesh(catHead,sphere,amber,[side*.028,.008,.043],[.014,.009,.009]);
    mesh(catHead,sphere,darkCat,[side*.029,.008,.051],[.004,.007,.003]);
    mesh(catHead,sphere,muzzle,[side*.016,-.019,.042],[.022,.015,.024]);
    for (let i=0;i<3;i++) {
      const whisker = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(side*.024,-.013-i*.004,.060),
        new THREE.Vector3(side*.051,-.012-i*.006,.072),
        new THREE.Vector3(side*.083,-.013-i*.011,.059),
      ]);
      catHead.add(new THREE.Line(whisker,whiskerInk));
    }
  }
  mesh(catHead,new THREE.ConeGeometry(.012,.010,3),nose,[0,-.012,.066],[1,1,.43]).rotation.z=Math.PI;
  const catLegs = [];
  for (const side of [-1,1]) {
    for (const front of [-1,1]) {
      const upper = mesh(cat,sphere,ginger,[0,0,0],[1,1,1]);
      const lower = mesh(cat,sphere,ginger,[0,0,0],[1,1,1]);
      const paw = mesh(cat,sphere,muzzle,[0,0,0],[.022,.013,.031]);
      catLegs.push({upper,lower,paw,side,front});
    }
  }
  const tail = new THREE.Group();
  tail.position.set(0,.207,-.169);
  catBody.add(tail);
  const tailCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(),new THREE.Vector3(.010,.048,-.076),
    new THREE.Vector3(.035,.118,-.144),new THREE.Vector3(.067,.177,-.186),
    new THREE.Vector3(.096,.175,-.211),
  ]);
  const tailMesh = new THREE.TubeGeometry(tailCurve,28,.018,8,false);
  const tailPoints = tailMesh.attributes.position;
  const tipPoint = new THREE.Vector3();
  for (let ring=0;ring<=28;ring++) {
    const fraction = ring/28;
    tailCurve.getPointAt(fraction,tipPoint);
    for (let point=0;point<9;point++) {
      const index = ring*9+point;
      const taper = 1-.70*fraction**2;
      tailPoints.setXYZ(index,tipPoint.x+(tailPoints.getX(index)-tipPoint.x)*taper,
        tipPoint.y+(tailPoints.getY(index)-tipPoint.y)*taper,tipPoint.z+(tailPoints.getZ(index)-tipPoint.z)*taper);
    }
  }
  colorFur(tailMesh,index => .72*THREE.MathUtils.smoothstep(Math.cos(Math.floor(index/9)*1.45),.20,.82));
  mesh(tail,tailMesh,tabby,[0,0,0],[1,1,1]);
  const leftCatPath = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-2.62,0,3.75),new THREE.Vector3(-2.56,0,1.86),
    new THREE.Vector3(-2.48,0,.93),new THREE.Vector3(-2.66,0,.73),
    new THREE.Vector3(-2.75,0,1.20),new THREE.Vector3(-2.80,0,2.22),
    new THREE.Vector3(-3.32,0,3.44),
  ],false,"centripetal");
  const rightCatPath = new THREE.CatmullRomCurve3([
    new THREE.Vector3(4.65,0,.49),new THREE.Vector3(3.06,0,.33),
    new THREE.Vector3(2.30,0,-.18),new THREE.Vector3(2.13,0,-.58),
    new THREE.Vector3(2.71,0,-.75),new THREE.Vector3(4.68,0,-.83),
  ],false,"centripetal");
  const catTravel = new THREE.Vector3();
  function animateCat(elapsed,path) {
    const progress = (elapsed-350)/6900;
    cat.visible = Boolean(path) && progress>=0 && progress<1;
    if (!cat.visible) return;
    path.getPointAt(progress,cat.position);
    path.getTangentAt(progress,catTravel);
    cat.rotation.y = Math.atan2(catTravel.x,catTravel.z);
    const stride = progress*path.getLength()/.30;
    const rise = .006*Math.cos(stride*Math.PI*4);
    catBody.position.y = rise;
    for (const {upper,lower,paw,side,front} of catLegs) {
      const phase = (stride+(side===-1 ? .5 : 0)+(front===-1 ? .27 : 0))%1;
      const swing = phase>.64 ? (phase-.64)/.36 : 0;
      const footTravel = phase<=.64 ? .096-.192*phase/.64 : -.096+.192*ease(swing);
      const lift = Math.sin(Math.PI*swing)*.044;
      const x = side*.049;
      const rootZ = front===1 ? .107 : -.124;
      const hip = new THREE.Vector3(x,.172+rise,rootZ);
      const ankle = new THREE.Vector3(x,.026+lift,rootZ+footTravel);
      const knee = hip.clone().lerp(ankle,.49);
      knee.z += front===1 ? -.022 : .031;
      aimLimb(upper,hip,knee,front===1 ? .019 : .025);
      aimLimb(lower,knee,ankle,.012);
      paw.position.set(x,.014+lift,ankle.z+.012);
    }
    tail.rotation.y = .19*Math.sin(stride*Math.PI*.85);
    tail.rotation.x = .09*Math.cos(stride*Math.PI);
    catHead.rotation.y = .16*Math.sin(progress*Math.PI*3);
    catHead.rotation.x = .055*Math.cos(stride*Math.PI*2);
  }

  const nameTags = Object.fromEntries(Object.keys(guests).map(name => {
    const tag = document.createElement("span");
    tag.className = "dinner-name-tag";
    tag.textContent = name;
    tag.setAttribute("aria-hidden","true");
    host.append(tag);
    return [name,tag];
  }));
  const tagPosition = new THREE.Vector3();

  function alignNameTags() {
    for (const [name,{head,body}] of Object.entries(guests)) {
      const tag = nameTags[name];
      head.localToWorld(tagPosition.set(0,.29,0)).project(camera);
      tag.hidden = !head.visible || !body.visible || Math.abs(tagPosition.x)>1.05 || Math.abs(tagPosition.y)>1.05 || tagPosition.z>1;
      tag.style.left = (tagPosition.x*.5+.5)*100+"%";
      tag.style.top = (.5-tagPosition.y*.5)*100+"%";
      if (name === "You") tag.textContent = host.dataset.playerName || "You";
    }
  }

  const props = {};
  function prop(name, build) {
    const group = new THREE.Group();
    group.visible = false;
    scene.add(group);
    props[name] = group;
    build(group);
  }
  const glass = material(0x91c4d3,.26);
  prop("door", group => {
    mesh(group,cube,material(0x9b653f),[-.29,.92,0],[.57,1.83,.075]);
    mesh(group,sphere,material(0xe6ba73),[-.50,1,.06],[.033,.033,.033]);
  });
  prop("oven", group => {
    mesh(group,cube,material(0x706050),[0,.51,0],[.75,1.02,.51]);
    mesh(group,cube,material(0xd7bca1),[0,1.03,0],[.79,.065,.55]);
    mesh(group,cube,steel,[0,.62,.266],[.59,.62,.028]);
    mesh(group,cube,material(0x403536,.28),[0,.57,.283],[.49,.33,.022]);
    mesh(group,cube,new THREE.MeshBasicMaterial({color:0xa75932}),[0,.56,.298],[.37,.22,.008]);
    mesh(group,cube,steel,[0,.78,.318],[.43,.025,.048]);
    for (const x of [-.15,0,.15]) {
      const knob = mesh(group,cylinder,steel,[x,.887,.298],[.023,.032,.023]);
      knob.rotation.x = Math.PI/2;
    }
  });
  prop("bread", group => {
    mesh(group,cylinder,material(0xa67445),[0,.02,0],[.15,.058,.115]);
    for (const x of [-.07,0,.07]) mesh(group,sphere,material(0xe8ba71),[x,.065,0],[.045,.038,.075]);
  });
  function vessel(group, radius, height) {
    const profile = [[0,0],[radius*.87,0],[radius,height],[radius-.007,height],[radius*.87-.007,.009],[0,.009]]
      .map(([x,y]) => new THREE.Vector2(x,y));
    mesh(group,new THREE.LatheGeometry(profile,28),glass,[0,0,0],[1,1,1]);
  }
  prop("pitcher", group => {
    vessel(group,.072,.15);
    mesh(group,cube,glass,[.075,.094,0],[.105,.025,.028]);
  });
  prop("stream", group => mesh(group,cylinder,glass,[0,0,0],[.012,.19,.012]));
  prop("cup", group => vessel(group,.043,.11));
  const water = new THREE.MeshPhysicalMaterial({color:0xaad5dc,roughness:.16,transparent:true,opacity:.58,depthWrite:false});
  prop("spill", group => {
    for (const [x,z,width,depth] of [[0,0,.085,.05],[.052,.019,.047,.034],[.021,-.039,.038,.026]]) {
      const patch = mesh(group,sphere,water,[x,.002,z],[width,.0025,depth]);
      patch.castShadow = false;
    }
  });
  const drops = Array.from({length:7},(_,index) => {
    const drop = mesh(scene,sphere,water,[0,0,0],[.006,.009,.006]);
    drop.castShadow = false;
    drop.visible = false;
    return drop;
  });
  prop("tray", group => {
    mesh(group,cube,steel,[0,.02,0],[.35,.035,.25]);
    for (const side of [-1,1]) {
      mesh(group,cube,steel,[side*.204,.031,0],[.014,.012,.071]);
      for (const z of [-.035,.035]) {
        mesh(group,cube,steel,[side*.188,.031,z],[.048,.012,.012]);
      }
    }
    for (const x of [-.09,.02,.12]) mesh(group,sphere,material(0xbd773f),[x,.052,0],[.043,.027,.062]);
  });
  prop("speaker", group => {
    mesh(group,cube,material(0x302a34),[0,.07,0],[.13,.14,.1]);
    mesh(group,cylinder,steel,[0,.07,.054],[.034,.012,.034]).rotation.x = Math.PI/2;
  });
  prop("cake", group => {
    mesh(group,cylinder,china,[0,.012,0],[.115,.022,.115]);
    const slice = new THREE.CylinderGeometry(.088,.088,.066,3,1,false,0,Math.PI*2);
    mesh(group,slice,material(0xd99b68),[0,.055,0],[1,1,1]);
    mesh(group,slice,material(0xf3dac0),[0,.09,0],[1,.12,1]);
  });
  prop("plates", group => {
    for (let index=0;index<3;index++) mesh(group,cylinder,china,[0,index*.025,0],[.14,.021,.14]);
  });
  prop("phone", group => {
    mesh(group,cube,material(0x2b2930),[0,0,0],[.075,.013,.14]);
    mesh(group,cube,glass,[0,.008,0],[.062,.006,.115]);
  });

  function setProp(name, x, y, z, tilt = 0, yaw = 0) {
    const object = props[name];
    object.visible = true;
    object.position.set(x,y,z);
    object.rotation.set(0,yaw,tilt);
  }

  function gesture(name, side, lift, sweep = 0) {
    const arm = guests[name].arms[side];
    arm.rotation.x = -lift;
    arm.rotation.z = (side ? .24 : -.24) + sweep;
  }

  const joint = new THREE.Vector3();
  const direction = new THREE.Vector3();
  const up = new THREE.Vector3(0,1,0);
  function legSegment(part, x, y1, z1, y2, z2, width) {
    part.position.set(x,(y1+y2)/2,(z1+z2)/2);
    direction.set(0,y2-y1,z2-z1);
    part.scale.set(width,direction.length()/2+.037,width);
    part.quaternion.setFromUnitVectors(up,joint.copy(direction).normalize());
  }

  function aimLimb(part, from, to, width) {
    part.position.copy(from).lerp(to,.5);
    direction.subVectors(to,from);
    part.scale.set(width,direction.length()/2+.025,width);
    part.quaternion.setFromUnitVectors(up,joint.copy(direction).normalize());
  }

  const collisionPoint = new THREE.Vector3();
  function overTable(point) {
    return (point.x/1.20)**2 + (point.z/.85)**2 < 1;
  }

  function keepHandsAboveTable() {
    for (const {arms} of Object.values(guests)) {
      for (const arm of arms) {
        if (!arm.visible) continue;
        const forearm = arm.forearm;
        // Check the ends and centre of the forearm before lowering a gesture.
        for (let correction=0;correction<12;correction++) {
          const isIntersecting = [-.72,0,.72].some(along => {
            forearm.localToWorld(collisionPoint.set(0,0,along));
            return overTable(collisionPoint) && collisionPoint.y<.837;
          });
          if (!isIntersecting) break;
          arm.rotation.x -= .095;
        }
      }
    }
  }

  function hold(name, index, propName, x, y, z) {
    const {body, arms, reaching} = guests[name];
    const object = props[propName];
    const arm = reaching[index];
    const target = body.worldToLocal(object.localToWorld(new THREE.Vector3(x,y,z)));
    const side = index ? 1 : -1;
    const shoulder = new THREE.Vector3(side*.224,.99,.015);
    const elbow = shoulder.clone().lerp(target,.52);
    elbow.y -= .075;
    elbow.x += side*.035;
    body.localToWorld(collisionPoint.copy(elbow));
    if (overTable(collisionPoint) && collisionPoint.y<.85) {
      elbow.y += .85-collisionPoint.y;
    }
    arms[index].visible = false;
    arm.group.visible = true;
    aimLimb(arm.upper,shoulder,elbow,.072);
    const supportingDish = propName === "plates" || propName === "tray";
    const wrist = supportingDish ? target.clone().lerp(elbow,.12) : target;
    aimLimb(arm.lower,elbow,wrist,supportingDish ? .031 : .044);
    arm.palm.visible = !supportingDish;
    arm.plateHand.visible = supportingDish;
    arm.palm.position.copy(target);
    if (supportingDish) arm.plateHand.position.copy(target);
  }

  const ease = value => {
    const t = THREE.MathUtils.clamp(value,0,1);
    return t*t*(3-2*t);
  };

  function pose(name, rise = 0, offset = 0, gait = 0, motion = 0) {
    const {body, legs} = guests[name];
    const lift = .24*rise;
    body.position.set(offset,lift,-.16*rise);
    body.rotation.set(0,0,0);
    for (const {thigh, shin, shoe, side} of legs) {
      const x = side*.108;
      const step = (gait+(side>0 ? .5 : 0))%1;
      const travel = step<.62 ? .115-.23*step/.62 : -.115+.23*ease((step-.62)/.38);
      const clearance = step<.62 ? 0 : .076*Math.sin(Math.PI*(step-.62)/.38);
      const kneeY = THREE.MathUtils.lerp(.475,.43-lift,rise)+motion*.28*clearance;
      const kneeZ = THREE.MathUtils.lerp(.31,.06,rise)+motion*.58*travel;
      const ankleZ = THREE.MathUtils.lerp(.35,.03,rise)+motion*travel;
      const ankleY = .069-lift+motion*clearance;
      legSegment(thigh,x,.575,-.025,kneeY,kneeZ,.073);
      legSegment(shin,x,kneeY,kneeZ,ankleY,ankleZ,.055);
      shoe.position.set(x,.041-lift+motion*clearance,ankleZ+.045);
      shoe.rotation.x = motion*(step<.62 ? 0 : -.23*Math.sin(Math.PI*(step-.62)/.38));
    }
  }

  const player = guests.You;
  const entryStart = new THREE.Vector3(-2.15,0,-2.70);
  const chairSide = player.person.localToWorld(new THREE.Vector3(.68,0,-.16));
  const entryPath = new THREE.CatmullRomCurve3([
    entryStart,new THREE.Vector3(-2.16,0,-2.29),
    new THREE.Vector3(-2.23,0,-1.17),new THREE.Vector3(-2.25,0,.35),
    new THREE.Vector3(-1.89,0,.96),chairSide,
  ],false,"centripetal");
  const routePoint = new THREE.Vector3();
  const routeTangent = new THREE.Vector3();

  const leo = guests.Leo;
  const leoPath = new THREE.CatmullRomCurve3([
    new THREE.Vector3(5.15,0,-.65),new THREE.Vector3(3.12,0,-.75),
    new THREE.Vector3(2.14,0,-.81),
    leo.person.localToWorld(new THREE.Vector3(.68,0,-.16)),
  ],false,"centripetal");
  const maya = guests.Maya;
  const mayaPath = new THREE.CatmullRomCurve3([
    maya.person.localToWorld(new THREE.Vector3(.77,0,-.42)),
    maya.person.localToWorld(new THREE.Vector3(.73,0,-.29)),
    maya.person.localToWorld(new THREE.Vector3(.68,0,-.16)),
  ],false,"centripetal");

  function walkToSeat(name, path, elapsed, walkDuration, reverse = false) {
    const actor = guests[name];
    const seconds = Math.max(0,elapsed)/1000;
    const pause = .72;
    const travel = THREE.MathUtils.clamp((seconds-pause)/walkDuration,0,1);
    const offset = reverse ? ease(seconds/pause) : 1-ease((seconds-pause-walkDuration)/.84);
    const sit = reverse ? 1-offset : ease((seconds-pause-walkDuration-.20)/.64);
    const u = reverse ? 1-travel : travel;
    const routeDistance = travel*path.getLength();
    const moving = Math.min(ease(travel*12),ease((1-travel)*12));
    pose(name,1-sit,0,routeDistance/.43,moving);
    if ((!reverse && travel >= 1) || (reverse && travel <= 0)) {
      actor.body.position.x = .68*offset;
      return;
    }
    path.getPointAt(u,routePoint);
    path.getTangentAt(u,routeTangent);
    if (reverse) routeTangent.negate();
    const heading = Math.atan2(routeTangent.x,routeTangent.z);
    const seatedHeading = actor.person.rotation.y;
    const delta = Math.atan2(Math.sin(heading-seatedHeading),Math.cos(heading-seatedHeading));
    const facing = reverse ? ease(travel*7) : ease((1-travel)*6);
    actor.body.rotation.y = delta*facing;
    actor.person.worldToLocal(routePoint);
    actor.body.position.x = routePoint.x;
    actor.body.position.z = routePoint.z;
    const swing = Math.sin(routeDistance/.43*2*Math.PI)*.38*moving;
    gesture(name,0,swing);
    gesture(name,1,-swing);
  }

  const moments = {
    arrival(t) {
      pose("Sam",true,-.63);
      gesture("Sam",1,1.15*t,.63*t);
      gesture("Maya",0,.7*t,-.4*t);
    },
    oven(t) {
      pose("Sam",true,-.63);
      guests.Sam.head.rotation.y = -.55*t;
      gesture("Sam",0,1.1*t,-.2*t);

    },
    bread(t) {
      const {person} = guests.Sam;
      const basket = person.localToWorld(new THREE.Vector3(-.22,.799+.07*Math.sin(Math.PI*t),.46+.05*t));
      setProp("bread",basket.x,basket.y,basket.z,0,person.rotation.y);
      if (t<.97) hold("Sam",0,"bread",0,.019,-.112);
      guests.Maya.head.rotation.y = .3-.6*t;
    },
    water(t) {
      const choice = host.dataset.replyChoice;
      const cupX = .82;
      const cupZ = -.09;
      setProp("cup",cupX,.793,cupZ);
      if (choice === "0" || choice === "2") {
        setProp("pitcher",.94-.022*t,.793+.235*t,-.27+.18*t,.95*t);
        hold("Leo",0,"pitcher",.065,.078,-.04);
        if (t>.83) {
          const spout = props.pitcher.localToWorld(new THREE.Vector3(-.067,.139,0));
          const target = new THREE.Vector3(cupX,.875,cupZ);
          const stream = props.stream;
          stream.visible = true;
          stream.position.copy(spout).lerp(target,.5);
          direction.subVectors(target,spout);
          stream.scale.y = direction.length()/.19;
          stream.quaternion.setFromUnitVectors(up,joint.copy(direction).normalize());
        }
      } else if (choice === "1") {
        setProp("pitcher",.94+.018*t,.793+.046*Math.sin(Math.PI*t),-.27+.08*t);
        if (t<.97) hold("Leo",0,"pitcher",.065,.078,-.04);
      } else {
        setProp("pitcher",.94,.793,-.27);
        gesture("Leo",0,.76*t);
      }
    },
    spill(t) {
      const knocked = ease((t-.09)/.36);
      const tilt = Math.PI*.49*knocked;
      const touch = Math.sin(Math.PI*ease(t/.32));
      setProp("cup",.36+.031*knocked,.793+.043*Math.sin(tilt),.42,-tilt);
      gesture("You",0,.65*touch,-.18*touch);
      setProp("bread",-.51-.12*ease((t-.20)/.46),.799,-.40);
      if (t>.20 && t<.69) hold("Maya",1,"bread",.02,.049,-.10);
      if (t>.26) {
        setProp("spill",.52,.793,.43);
        const spread = .04+.96*ease((t-.26)/.61);
        props.spill.scale.set(spread,1,spread);
      }
      drops.forEach((drop,index) => {
        const flight = (t-.23-index*.017)/.36;
        if (flight<=0 || flight>=1) return;
        drop.visible = true;
        drop.position.set(.435+(.10+index*.013)*flight,
          .8+.065*Math.sin(Math.PI*flight)+.049*(1-flight),.426+(index-3)*.013*flight);
      });
    },
    meeting(t) {
      guests.Leo.head.rotation.x = .14*t;
      gesture("Leo",0,.92*t,-.29*t);
      gesture("Leo",1,.6*t,.30*t);
      guests.Sam.head.rotation.y = -.36*t;
    },
    tray(t) {
      const placing = host.dataset.replyChoice !== undefined;
      const {person} = guests.Sam;
      const trayPosition = person.localToWorld(new THREE.Vector3(
        .015, 1.045-(placing ? .253*t : 0), .36+(placing ? .21 : .05)*t
      ));
      setProp("tray",trayPosition.x,trayPosition.y,trayPosition.z,0,person.rotation.y);
      if (!placing || t<.97) {
        hold("Sam",0,"tray",-.221,.021,0);
        hold("Sam",1,"tray",.221,.021,0);
      }
    },
    music(t) {
      setProp("speaker",-.58+.09*t,.791,-.38);
      guests.Maya.torso.rotation.x = .19*t;
      guests.Maya.head.position.z = .012+.051*t;
      if (t>.2 && t<.96) hold("Sam",1,"speaker",-.06,.065,0);
    },
    week(t) {
      guests.Maya.head.rotation.z = -.17*t;
      gesture("Maya",1,.97*t,.31*t);
      guests.Leo.head.rotation.y = .28*t;
    },
    joke(t) {
      guests.Leo.head.rotation.x = .43*t;
      guests.Leo.head.position.y = 1.31-.045*t;
      gesture("Sam",0,.7*(1-t),-.23);
    },
    cake(t) {
      setProp("cake",.02,.801,.03);
      gesture("Maya",0,1.03*t,-.2*t);
      guests.Maya.head.rotation.x = .16*t;
    },
    clearing(t) {
      setProp("plates",-.76-.20*t,.823+.15*t,.01-.09*t);
      props.plates.rotation.y = guests.Sam.person.rotation.y;
      hold("Sam",0,"plates",-.147,-.024,-.009);
      hold("Sam",1,"plates",.147,-.024,-.009);
    },
    memory(t) {
      gesture("Maya",1,.52*t,.12*t);
      guests.Maya.head.rotation.y = -.30*t;
      guests.Maya.head.rotation.x = .15*t;
    },
    numbers(t) {
      setProp("phone",-.66,.804+.18*t,-.14,-.40*t);
      hold("Sam",1,"phone",.027,-.012,-.035);
      guests.Maya.head.rotation.x = .23*t;
    },
    goodbye(t) {
      pose("Sam",true,-.64-.09*t);
      gesture("Sam",1,1.85,.59*Math.sin(t*7));
      if (host.dataset.replyChoice === "0") {
        setProp("phone",.36,.804,.40);
      }
    },
  };
  const reduced = matchMedia("(prefers-reduced-motion: reduce)");
  let activeMoment;
  let activeChoice;
  let began = 0;
  let sceneBegan = 0;
  let departureReported = false;

  function draw(time = performance.now()) {
    const moment = host.dataset.moment;
    const choice = host.dataset.replyChoice;
    if (moment !== activeMoment) sceneBegan = time;
    if (moment !== activeMoment || choice !== activeChoice) {
      activeMoment = moment;
      activeChoice = choice;
      began = time;
    }
    guests.Leo.body.visible = moment !== "arrival";
    for (const [index,{flame,light}] of flames.entries()) {
      const flicker = reduced.matches ? 0 : Math.sin(time/86+index*1.7);
      flame.scale.y = .023 + .004*flicker;
      flame.rotation.z = .16*flicker;
      light.intensity = .22 + .035*flicker;
    }
    const speaking = host.dataset.speaker;
    for (const [name, guest] of Object.entries(guests)) {
      const {head,mouth,arms,reaching,torso,eyeGroups} = guest;
      const active = name === speaking && !reduced.matches;
      pose(name);
      head.position.set(0,1.31,.012);
      head.rotation.set(active ? .07*Math.sin(time/190) : 0,0,0);
      torso.rotation.x = 0;
      const blinkPhase = (time + name.charCodeAt(0)*215)%4800;
      const blink = !reduced.matches && blinkPhase<150 ? Math.sin(Math.PI*blinkPhase/150) : 0;
      eyeGroups.forEach(eye => { eye.scale.y = 1-.93*blink; });
      mouth.scale.y = active ? .009+.006*Math.abs(Math.sin(time/105)) : .009;
      arms.forEach((arm,side) => {
        arm.visible = true;
        reaching[side].group.visible = false;
        gesture(name,side,0);
      });
    }
    Object.values(props).forEach(object => { object.visible = false; });
    drops.forEach(drop => { drop.visible = false; });
    const cycle = ((Math.max(0,time-began)/4600)%1)*2*Math.PI;
    const progress = reduced.matches ? .9 : .5-.5*Math.cos(cycle);
    const elapsed = reduced.matches ? 6200 : time-sceneBegan;
    const leaving = moment === "goodbye" && choice !== undefined;
    const departureElapsed = reduced.matches ? 6400 : Math.max(0,time-began);
    guests.You.body.visible = !leaving || departureElapsed < 5080;
    const doorOpen = moment === "arrival"
      ? ease(elapsed/680)*(1-ease((elapsed-2400)/710))
      : leaving ? ease((departureElapsed-3200)/680)*(1-ease((departureElapsed-5080)/820)) : 0;
    setProp("door",doorway.right,0,doorway.depth,0,-1.46*doorOpen);
    setProp("oven",-.93,0,-2.11,0,.13);
    moments[moment]?.(moment === "spill" ? ease(elapsed/2000) : progress);
    if (moment === "arrival" || moment === "oven") pose("Maya",1,.77);
    if (moment === "bread") {
      if (choice === undefined) pose("Maya",1,.77);
      else walkToSeat("Maya",mayaPath,reduced.matches ? 6200 : time-began,.55);
    }
    if (moment === "oven") walkToSeat("Leo",leoPath,elapsed,3.4);
    if (moment === "arrival" || leaving) {
      walkToSeat("You",entryPath,leaving ? departureElapsed : elapsed,4.3,leaving);
    } else if (host.dataset.replyChoice !== undefined) {
      gesture("You",1,.26+.52*progress,.27*progress);
      guests.You.head.rotation.y = -.18*progress;
    }
    keepHandsAboveTable();
    placeGlasses[3].visible = moment !== "water" && moment !== "spill";
    platter.visible = !["tray","cake","clearing","numbers","goodbye"].includes(moment);
    platedStarter.visible = ["bread","water","spill","meeting"].includes(moment) || (moment === "tray" && (choice === undefined || progress<=.87));
    platedMain.visible = ["music","week","joke"].includes(moment) || (moment === "tray" && choice !== undefined && progress>.87);
    platedDessert.visible = moment === "cake" && choice !== undefined;
    food.visible = host.dataset.setting === "dinner" && platter.visible && !platedMain.visible;
    const playing = ["bread","water","spill","meeting","tray","music","week","joke","cake"].includes(moment)
      && host.dataset.musicPaused !== "true";
    if (playing && !reduced.matches) record.rotation.y = -(time/1000)*Math.PI*1.11;
    musicNotes.forEach((note,index) => {
      note.visible = playing;
      if (!playing) return;
      const float = reduced.matches ? (index+1)/4 : (time/3400+index/3)%1;
      note.position.set(playerX+.095*Math.sin(float*5+index),1.06+float*.61,playerZ+.12);
      note.scale.setScalar(.125+float*.045);
      note.material.opacity = Math.sin(float*Math.PI)*.87;
    });
    const catPath = {music:leftCatPath, week:rightCatPath}[moment];
    animateCat(elapsed,reduced.matches ? null : catPath);
    const walking = !reduced.matches && (
      (moment === "arrival" && elapsed>=750 && elapsed<5030) ||
      (leaving && departureElapsed>=730 && departureElapsed<4980)
    );
    updateView(moment,time,walking,reduced.matches);
    drawRain(reduced.matches ? 0 : time);
    renderer.render(scene,camera);
    alignNameTags();
    if (leaving && departureElapsed>=6320 && !departureReported) {
      departureReported = true;
      host.dispatchEvent(new Event("dinner-departed"));
    }
  }

  function resize() {
    const {clientWidth:width,clientHeight:height} = host;
    if (!width || !height) return;
    renderer.setSize(width,height,false);
    camera.aspect = width/height;
    camera.fov = camera.aspect < 1.55 ? 43 : 34;
    camera.updateProjectionMatrix();
    draw();
  }
  resize();
  new ResizeObserver(resize).observe(host);
  new MutationObserver(() => draw()).observe(host,{attributes:true,attributeFilter:["data-setting","data-speaker","data-moment","data-reply-choice","data-player-name","data-music-paused"]});
  new IntersectionObserver(([entry]) => {
    renderer.setAnimationLoop(entry.isIntersecting && !reduced.matches ? draw : null);
    if (entry.isIntersecting) resize();
  }).observe(host);
  renderer.domElement.addEventListener("webglcontextlost", event => {
    event.preventDefault();
    renderer.setAnimationLoop(null);
    host.classList.remove("has-dinner-scene");
    renderer.domElement.hidden = true;
    host.dispatchEvent(new Event("dinner-departed"));
  });
}
