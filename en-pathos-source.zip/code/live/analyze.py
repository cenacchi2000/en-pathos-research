"""Summarize session-level scores for the two randomized study arms."""
import argparse
import csv
import json
import sqlite3
from pathlib import Path
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("database", type=Path)
parser.add_argument("checkpoint")
parser.add_argument("--csv", type=Path)
args = parser.parse_args()
items = dict(json.loads((Path(__file__).parent / "web/evaluation.json").read_text()))
pets = dict(json.loads((Path(__file__).parent / "web/pets.json").read_text()))
emoharbor = [item[0] for item in json.loads((Path(__file__).parent / "web/emoharbor.json").read_text())]
scale_keys = {"pets_er_mean": [k for k in pets if k.startswith("pets_e")],
              "pets_ut_mean": [k for k in pets if k.startswith("pets_u")]}
with sqlite3.connect(args.database.resolve().as_uri() + "?mode=ro", uri=True) as db:
    rows = db.execute("SELECT arm, turns, scores FROM sessions WHERE checkpoint = ?", (args.checkpoint,)).fetchall()

summary, export, means = {}, [], {}
arms = dict.fromkeys(("group_1_trained", "group_2_generic"))
arms.update(dict.fromkeys(sorted(arm for arm, _, _ in rows if arm.startswith("group_2:"))))
for arm in arms:
    arm_rows = [(turns, json.loads(scores) if scores else {}) for group, turns, scores in rows if group == arm]
    records = []
    for turns, scores in arm_rows:
        subscales = {
            name: float(np.mean([scores[key] for key in keys]))
            if all(scores.get(key) is not None for key in keys) else None
            for name, keys in scale_keys.items()
        }
        records.append(subscales["pets_er_mean"])
        export.append({"arm": arm, "turns": turns, "submitted": bool(scores), **subscales,
                       **{key: scores.get(key) for key in (*items, *pets, *emoharbor)}})
    means[arm] = np.array([x for x in records if x is not None])
    summary[arm] = {"assigned": len(records), "submitted": sum(bool(s) for _, s in arm_rows),
                    "pets_er_scored": len(means[arm]), "pets_er_mean": float(means[arm].mean()) if len(means[arm]) else None}
    trust = [row["pets_ut_mean"] for row in export if row["arm"] == arm and row["pets_ut_mean"] is not None]
    summary[arm]["pets_ut_mean"] = float(np.mean(trust)) if trust else None
if min(len(means["group_1_trained"]), len(means["group_2_generic"])) >= 2:
    rng = np.random.default_rng(42)
    trained, generic = means["group_1_trained"], means["group_2_generic"]
    draws = rng.choice(trained, (5000, len(trained))).mean(axis=1) - rng.choice(generic, (5000, len(generic))).mean(axis=1)
    summary["pets_er_trained_minus_generic"] = {"mean": float(trained.mean() - generic.mean()),
                                             "bootstrap_95": np.quantile(draws, [.025, .975]).tolist()}
if args.csv:
    with args.csv.open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["arm", "turns", "submitted", *scale_keys, *items, *pets, *emoharbor])
        writer.writeheader()
        writer.writerows(export)
print(json.dumps(summary, indent=2))
