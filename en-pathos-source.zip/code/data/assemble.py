"""Attach source-aligned AnnoMI video and assemble a full episode-isolated run."""
from collections import Counter, defaultdict
import csv
from datetime import timedelta
import hashlib
import json
import re
from pathlib import Path
import sys
from urllib.parse import parse_qs, urlparse

import av
import numpy as np
from PIL import Image

sys.path.insert(0, "outputs/en-pathos-listener")
from data import split

root = Path("work/full-four")
if "--from-cache" in sys.argv:
    rows = [json.loads(line) for line in (root / "nonmeld-cache.jsonl").read_text().splitlines()]
    cached = json.loads((root / "nonmeld-coverage.json").read_text())
    coverage, mesc_coverage = cached["annomi_coverage"], cached["mesc_coverage"]
else:
    source = Path("work/listener")
    transcripts = defaultdict(list)
    with (source / "annomi.csv").open(encoding="utf-8-sig") as file:
        for row in csv.DictReader(file):
            if row["mi_quality"] == "high":
                transcripts[row["transcript_id"]].append(row)

    def seconds(stamp):
        h, m, s = map(float, stamp.split(":"))
        return timedelta(hours=h, minutes=m, seconds=s).total_seconds()

    def aligned_features(container, start, end):
        stream = container.streams.video[0]
        if end <= start:
            raise ValueError("Empty clip interval")
        time_base = float(stream.time_base)
        origin = stream.start_time or 0
        container.seek(max(0, origin + int(start / time_base)), stream=stream, backward=True)
        frames = []
        for frame in container.decode(stream):
            if frame.pts is None:
                continue
            timestamp = (frame.pts - origin) * time_base
            if timestamp >= end:
                break
            if timestamp >= start:
                frames.append(np.asarray(frame.to_image().resize((32, 32), Image.Resampling.BILINEAR), dtype=np.float32) / 255)
        if len(frames) < 8:
            raise ValueError("Need at least eight frames")
        frames = np.asarray(frames)[np.linspace(0, len(frames) - 1, 8).round().astype(int)]
        rgb = frames.reshape(8, 4, 8, 4, 8, 3).mean((2, 4))
        motion = np.abs(np.diff(frames, axis=0, prepend=frames[:1])).reshape(8, 4, 8, 4, 8, 3).mean((2, 4))
        return np.concatenate((rgb, motion), axis=-1).reshape(8, 96).tolist()

    by_transcript = defaultdict(list)
    rows = []
    for line in (source / "turns.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row["source"] == "meld":
            continue
        if row["source"] == "annomi":
            by_transcript[row["item"].split("/")[1]].append(row)
        rows.append(row)

    # Optional source episodes from the MESC release timestamps.
    mesc_media = root / "mesc"
    mesc_turns = defaultdict(list)
    with Path("work/strategy/MESC.csv").open(encoding="utf-8-sig") as source_csv:
        for turn in csv.DictReader(source_csv):
            mesc_turns[turn["Dialogue_ID"]].append(turn)
    mesc_coverage = Counter()
    for row in rows:
        if row["source"] != "mesc":
            continue
        _, dialogue, index = row["item"].split("/")
        turn = mesc_turns[dialogue][int(index)]
        episode = mesc_media / f'S{int(turn["Season"]):02d}E{int(turn["Episode"]):02d}.mp4'
        if not episode.is_file():
            mesc_coverage["source_episode_unavailable"] += 1
            continue
        try:
            with av.open(str(episode)) as container:
                row["video"] = aligned_features(container, seconds(turn["StartTime"].replace(",", ".")), seconds(turn["EndTime"].replace(",", ".")))
        except (ValueError, OSError, av.FFmpegError):
            mesc_coverage["interval_unavailable"] += 1
        else:
            mesc_coverage["video_attached"] += 1

    incomplete_videos = set()
    for name in ("annomi-download.log", "annomi-train.log"):
        log = root / name
        if not log.exists():
            continue
        identity = None
        for line in log.read_text(errors="replace").splitlines():
            match = re.search(r"Destination: .*?/([^/]+)\.mp4$", line)
            if match:
                identity = match.group(1)
            elif identity and ("Skipping fragment" in line or "fragment not found" in line):
                incomplete_videos.add(identity)

    actual_groups = {}
    coverage = Counter()
    for identity, items in by_transcript.items():
        transcript = sorted(transcripts[identity], key=lambda row: int(row["utterance_id"]))
        url = urlparse(transcript[0]["video_url"])
        video_id = parse_qs(url.query).get("v", [url.path.strip("/")])[0]
        group = "annomi/" + hashlib.sha256(video_id.encode()).hexdigest()[:16]
        current = items[0]["split"]
        existing = actual_groups.get(group)
        if existing and existing != current:
            actual_groups[group] = "test" if "test" in (existing, current) else "validation"
        else:
            actual_groups[group] = current
        for row in items:
            row["group"] = group
        path = root / "annomi" / f"{video_id}.mp4"
        if video_id in incomplete_videos:
            coverage["incomplete_source_video"] += len(items)
            continue
        if not path.exists():
            coverage["source_video_unavailable"] += len(items)
            continue
        positions = {row["utterance_id"]: i for i,row in enumerate(transcript)}
        try:
            with av.open(str(path)) as container:
                for row in items:
                    index = positions[row["item"].rsplit("/",1)[1]]
                    try:
                        row["video"] = aligned_features(container, seconds(transcript[index]["timestamp"]), seconds(transcript[index+1]["timestamp"]))
                    except (ValueError, av.FFmpegError, IndexError):
                        coverage["interval_unavailable"] += 1
                    else:
                        coverage["video_attached"] += 1
        except (av.FFmpegError, OSError):
            coverage["source_decode_failure"] += len(items)
        print("AnnoMI", identity, dict(coverage), flush=True)
    for row in rows:
        if row["source"] == "annomi":
            row["split"] = actual_groups[row["group"]]
    if "--cache-nonmeld" in sys.argv:
        with (root / "nonmeld-cache.jsonl").open("w") as handle:
            for row in rows:
                handle.write(json.dumps(row) + "\n")
        (root / "nonmeld-coverage.json").write_text(json.dumps({"annomi_coverage":dict(coverage),"mesc_coverage":dict(mesc_coverage)}))
        raise SystemExit(0)
    if "--annomi-audit" in sys.argv:
        print("AnnoMI snapshot", dict(coverage), flush=True)
        raise SystemExit(0)
for part in ("train","dev","test"):
    rows.extend(json.loads(line) for line in (root / f"meld-{part}.jsonl").read_text().splitlines())
assignments = defaultdict(set)
for row in rows:
    assignments[row["group"]].add(row["split"])
assert all(len(splits) == 1 for splits in assignments.values())
out = root / "all-turns.jsonl"
with out.open("w") as handle:
    for row in rows:
        handle.write(json.dumps(row)+"\n")
report = {"annomi_coverage":dict(coverage), "mesc_coverage":dict(mesc_coverage), "counts":[dict(source=s,split=p,video=v,n=n) for (s,p,v),n in sorted(Counter((r["source"],r["split"],r["video"] is not None) for r in rows).items())]}
(root / "training-coverage.json").write_text(json.dumps(report,indent=2)+"\n")
print(report,flush=True)
