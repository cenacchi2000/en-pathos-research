import csv,io,json,sys,tarfile
from pathlib import Path
sys.path.insert(0,"outputs/en-pathos-listener")
import av
from data import record,video_features
output=Path("work/full-four/meld-video.jsonl")
annotated={(int(r["Dialogue_ID"]),int(r["Utterance_ID"])):r for r in csv.DictReader(open("work/meld-test.csv",encoding="utf-8-sig",errors="replace"))}
original=[json.loads(s) for s in Path("work/listener/turns.jsonl").read_text().splitlines()]
blocked={r["group"] for r in original if r["source"]=="meld" and r["split"]=="train"}
counts=dict(annotated=len(annotated),missing=0,no_next_or_same_speaker=0,training_episode=0,decode_failure=0,scored=0)
clips=set()
with tarfile.open(fileobj=sys.stdin.buffer,mode="r|gz") as outer:
    for member in outer:
        print(member.name,flush=True)
        if Path(member.name).name!="test.tar.gz": continue
        with tarfile.open(fileobj=outer.extractfile(member),mode="r|gz") as inner, output.open("w") as out:
            for clip in inner:
                if not clip.isfile() or not clip.name.endswith(".mp4"): continue
                name=Path(clip.name).stem
                try: d,u=map(int,name.replace("dia","").replace("_utt"," ").split())
                except ValueError: continue
                if (d,u) not in annotated or (d,u) in clips: continue
                clips.add((d,u))
                a,b=annotated[d,u],annotated.get((d,u+1))
                if not b or a["Speaker"]==b["Speaker"]:
                    counts["no_next_or_same_speaker"]+=1
                    continue
                group=f'meld/{a["Season"]}/{a["Episode"]}'
                if group in blocked:
                    counts["training_episode"]+=1
                    continue
                try:
                    path=Path("work/full-four/current.mp4")
                    path.write_bytes(inner.extractfile(clip).read())
                    video=video_features(path)
                except (av.FFmpegError,OSError,ValueError):
                    counts["decode_failure"]+=1
                    continue
                row=record("meld",group,f"meld/official-test/{d}/{u}",a["Utterance"],b["Utterance"],video=video)
                row["split"]="test"
                out.write(json.dumps(row)+"\n")
                counts["scored"]+=1
        break
    else:
        raise RuntimeError("MELD test archive unavailable")
counts["missing"]=len(annotated)-len(clips)
Path("work/full-four/meld-coverage.json").write_text(json.dumps(counts,indent=2)+"\n")
print(counts,flush=True)
