import json, sys
from pathlib import Path
from collections import Counter
import torch
from peft import PeftModel
from transformers import AutoTokenizer,AutoModelForCausalLM
sys.path.insert(0,"outputs/en-pathos-listener")
from train import EvidencePrefix,evaluate
from data import split
rows=[json.loads(x) for x in Path(sys.argv[1]).read_text().splitlines()]
rows=[r for r in rows if r["split"]=="test"]
if len(sys.argv)>3:
    rows=[r for r in rows if r["video"] is not None]
assert rows
torch.set_num_threads(4)
device="mps" if torch.backends.mps.is_available() else "cpu"
base="work/listener/smol"
tokenizer=AutoTokenizer.from_pretrained(base)
if tokenizer.pad_token_id is None:
    tokenizer.pad_token=tokenizer.eos_token
model=AutoModelForCausalLM.from_pretrained(base,dtype=torch.float32).to(device)
prefix=EvidencePrefix(model.config.hidden_size).to(device)
report={"counts":dict(Counter(r["source"] for r in rows)),"device":device,"metrics":{}}
def score(name,model,mode):
    report["metrics"][name]=evaluate(model,prefix,tokenizer,rows,device,mode)
    Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+"\n")
    print(name,report["metrics"][name],flush=True)
score("frozen_transcript",model,"text")
for variant in ("text","mixed"):
    ck=Path("work/listener")/variant
    adapted=PeftModel.from_pretrained(model,ck/"lora")
    prefix.load_state_dict(torch.load(ck/"prefix.pt",weights_only=True))
    score(variant+"_transcript",adapted,"text")
    if variant=="mixed":
        score("mixed_available_context",adapted,"full")
        if len(sys.argv)>3:
            score("mixed_middle_descriptor",adapted,"frame")
            score("mixed_shuffled_descriptors",adapted,"shuffled")
    model=adapted.unload()
