"""Analyze one En-Pathos server revision from a read-only SQLite snapshot."""
import argparse
import json
from pathlib import Path
import sqlite3

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from scipy.special import gammaln

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("database", type=Path)
parser.add_argument("revision")
parser.add_argument("output", type=Path)
args = parser.parse_args()

with sqlite3.connect(args.database.resolve().as_uri() + "?mode=ro", uri=True) as db:
    rows = db.execute("SELECT checkpoint, arm, turns, scores FROM sessions").fetchall()

arms = {
    "group_1_trained": "En-Pathos",
    "group_2_generic": "Gemma 4 12B",
    "group_2:mint-qwen3-1.7b": "MINT 1.7B",
    "group_2:psyllm-1.7b": "PsyLLM 1.7B",
}
emotional = [f"pets_e{i}" for i in range(1, 7)]
trust = [f"pets_u{i}" for i in range(1, 5)]
endpoints = {
    "PETS total": emotional + trust,
    "Emotional responsiveness": emotional,
    "Understanding and trust": trust,
    "Freedom from repetition": ["emoharbor_redundancy"],
}
assigned = dict.fromkeys(arms, 0)
completed = {name: [] for name in arms}
for revision, arm, turns, encoded in rows:
    if revision != args.revision:
        continue
    assigned[arm] += 1
    if turns < 3 or encoded is None:
        continue
    scores = json.loads(encoded)
    for key in emotional + trust:
        assert type(scores[key]) is int and 0 <= scores[key] <= 100, key
    assert type(scores["emoharbor_redundancy"]) is int and 1 <= scores["emoharbor_redundancy"] <= 5
    completed[arm].append(scores)

def values(records, keys):
    return np.array([np.mean([record[key] for key in keys]) for record in records])

def compare(first, second):
    result = stats.ttest_ind(first, second, equal_var=False)
    low, high = result.confidence_interval()
    return dict(difference=float(first.mean() - second.mean()), low=float(low), high=float(high),
                p=float(result.pvalue))

def holm(comparisons):
    running = 0
    for index, result in enumerate(sorted(comparisons, key=lambda result: result["p"])):
        running = max(running, (len(comparisons) - index) * result["p"])
        result["holm_p"] = min(1, running)

experimental = next(iter(arms))
controls = [r for arm in list(arms)[1:] for r in completed[arm]]
scores = completed[experimental]
primary = endpoints["PETS total"]
x, y = values(scores, primary), values(controls, primary)
metrics = {}
for name, keys in endpoints.items():
    first, second = values(scores, keys), values(controls, keys)
    metrics[name] = dict(**compare(first, second), mean_experimental=float(first.mean()),
                         mean_control=float(second.mean()), sd_experimental=float(first.std(ddof=1)),
                         sd_control=float(second.std(ddof=1)))
holm([metrics[name] for name in list(endpoints)[1:]])
by_model = {label: compare(x, values(completed[arm], primary))
            for arm, label in list(arms.items())[1:]}
holm(list(by_model.values()))
pooled_df = len(x) + len(y) - 2
pooled_sd = np.sqrt(((len(x)-1)*x.var(ddof=1)+(len(y)-1)*y.var(ddof=1))/pooled_df)
correction = np.exp(gammaln(pooled_df/2) - np.log(pooled_df/2)/2 - gammaln((pooled_df-1)/2))
g = (x.mean()-y.mean())/pooled_sd*correction
loo = [np.delete(x, i).mean()-y.mean() for i in range(len(x))]
loo += [x.mean()-np.delete(y, i).mean() for i in range(len(y))]
n_x, n_y = assigned[experimental], sum(assigned.values()) - assigned[experimental]
missing_x, missing_y = n_x-len(x), n_y-len(y)
summary = dict(total_completed=sum(turns >= 3 and encoded is not None for _, _, turns, encoded in rows),
               revision=args.revision, assigned=assigned, completed={k:len(v) for k,v in completed.items()},
               arm_means={arms[k]:float(values(v,primary).mean()) for k,v in completed.items()},
               arm_sds={arms[k]:float(values(v,primary).std(ddof=1)) for k,v in completed.items()},
               metrics=metrics, by_model=by_model, hedges_g=float(g),
               leave_one_out=[float(min(loo)),float(max(loo))],
               missing_bounds=[float(x.sum()/n_x-(y.sum()+100*missing_y)/n_y),
                               float((x.sum()+100*missing_x)/n_x-y.sum()/n_y)])
args.output.mkdir(parents=True,exist_ok=True)
(args.output/"live-analysis.json").write_text(json.dumps(summary,indent=2)+"\n")

questionnaires = {
    "PETS": list(zip(emotional + trust, [
        "Mental state", "Emotional\nintelligence", "Expresses\nemotion", "Sympathy",
        "Shows interest", "Supports coping", "Understands\ngoals", "Understands\nneeds",
        "Trust", "Understands\nintentions",
    ])),
    "Study-specific": [
        ("problem_understood", "Understands\nproblem"), ("knows_help", "Knows how\nto help"),
        ("specific_solutions", "Useful\nsolutions"), ("jumps_to_conclusions", "Avoids hasty\nconclusions"),
        ("respect", "Respect"), ("felt_better", "Helps me\nfeel better"),
        ("appropriate_clear", "Appropriate\nand clear"), ("think_through", "Helps me\nthink"),
        ("coherence", "Coherence"), ("assumptions", "Avoids\nassumptions"),
    ],
    "EMOHARBOR": [
        ("emoharbor_appropriateness", "Context fit"), ("emoharbor_adaptation", "Adaptation"),
        ("emoharbor_redundancy", "Low repetition"), ("emoharbor_consistency", "Consistency"),
        ("emoharbor_safety", "Safety\nand respect"),
    ],
}

def summarize_item(records, key):
    observed = np.array([record[key] for record in records if record.get(key) is not None])
    assert len(observed), key
    if key == "jumps_to_conclusions":
        observed = 6 - observed
    scaled = observed if key.startswith("pets_") else 25 * (observed - 1)
    return {"mean": float(scaled.mean()), "n": len(scaled)}

plt.rcParams.update({"font.size": 8, "pdf.fonttype": 42})
fig, panels = plt.subplots(1, 3, figsize=(7.0, 2.43), subplot_kw={"projection": "polar"})
fig.subplots_adjust(left=.065, right=.935, bottom=.25, top=.79, wspace=.59)
series = [(f"En-Pathos (n={len(scores)})", scores, "#13776d", "-"),
          (f"Pooled controls (n={len(controls)})", controls, "#685384", "--")]
item_results = {}
for axis, (title, items) in zip(panels, questionnaires.items()):
    angles = np.linspace(0, 2*np.pi, len(items), endpoint=False)
    axis.set_theta_zero_location("N")
    axis.set_theta_direction(-1)
    axis.set_xticks(angles, [label for _, label in items], fontsize=6.0)
    axis.tick_params(axis="x", pad=2)
    axis.set_ylim(0, 100)
    axis.set_yticks([25, 50, 75, 100])
    axis.set_yticklabels(["", "50", "", ""], fontsize=5.5, color="#49555b")
    axis.set_rlabel_position(45)
    axis.grid(color="#b3bdc2", alpha=.62, linewidth=.48)
    axis.spines["polar"].set_color("#a2adb3")
    axis.set_title(title, fontsize=8.5, fontweight="bold", y=1.22)
    for label, records, color, style in series:
        results = {key: summarize_item(records, key) for key, _ in items}
        item_results.setdefault(title, {})[label] = results
        means = [item["mean"] for item in results.values()]
        axis.plot(np.r_[angles, angles[0]], means + [means[0]], color=color,
                  linestyle=style, linewidth=1.45, marker="o", markersize=2, label=label)
        axis.fill(np.r_[angles, angles[0]], means + [means[0]], color=color, alpha=.08)
handles, labels = panels[0].get_legend_handles_labels()
fig.legend(handles, labels, loc="lower center", bbox_to_anchor=(.5, .015), ncol=2, frameon=False)
fig.savefig(args.output/"live-questionnaire-radar.pdf")
(args.output/"live-questionnaire-items.json").write_text(json.dumps(item_results, indent=2)+"\n")
