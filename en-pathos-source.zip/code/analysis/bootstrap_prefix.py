import collections,json
import numpy as np
rows=[json.loads(l) for l in open(__import__('sys').argv[1])]
assert len(rows)==2031
modes=list(rows[0]['scores'])
groups=collections.defaultdict(lambda:collections.defaultdict(lambda:np.zeros(len(modes)+1)))
for r in rows:
 n=r['tokens']
 groups[r['source']][r['group']]+=np.array([n]+[r['scores'][m]*n for m in modes])
rng=np.random.default_rng(42)
draw=np.zeros((10000,len(modes)+1))
total=np.zeros(len(modes)+1)
for corpus,g in groups.items():
 a=np.array(list(g.values()))
 print(corpus,len(a),a[:,0].sum(),np.exp(a[:,1:].sum(axis=0)/a[:,0].sum()))
 total+=a.sum(axis=0)
 draw+=a[rng.integers(0,len(a),(len(draw),len(a)))].sum(axis=1)
i=1+modes.index('ordered')
print('total',total[0])
for j,m in enumerate(modes,1):
 print(m,round(np.exp(total[j]/total[0]),4),round((total[j]-total[i])/total[0],5),np.quantile((draw[:,j]-draw[:,i])/draw[:,0],[.025,.975]).round(5))
